#! /usr/bin/env python
# -*- coding: utf-8 -*-
####################
# Copyright (c) 2017-2022 Alan Carter. All rights reserved.
#

################################################################################
# Imports
################################################################################
import json
import requests
import urllib.request
import time
import datetime
import re
import sys
import math
import threading

################################################################################
# Globals
################################################################################

########################################
def updateVar(name, value, folder=0):
    if name not in indigo.variables:
        indigo.variable.create(name, value=value, folder=folder)
    else:
        indigo.variable.updateValue(name, value)

################################################################################
class Plugin(indigo.PluginBase):
    ########################################
    # Class properties
    ########################################
    
    ########################################
    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        indigo.PluginBase.__init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
        self.userName = self.pluginPrefs.get("userName", "None")
        self.userPass = self.pluginPrefs.get("userPass", "None")
        self.clientId = self.pluginPrefs.get("clientId", "None")
        self.clientSecret = self.pluginPrefs.get("clientSecret", "None")
        self.accessToken = self.pluginPrefs.get("accessToken", "")
        self.refreshToken = self.pluginPrefs.get("refreshToken", "")
        self.expiration = int(self.pluginPrefs.get("expiration", 0))
        self.saveTokens = self.pluginPrefs.get("saveTokens", False)
        self.presence = self.pluginPrefs.get("Presence", False)
        self.welcome = self.pluginPrefs.get("Welcome", False)
        self.pollFreq = float(self.pluginPrefs.get("netatmoFreq", 0.5))
        self.pollF = int(self.pollFreq * 60)
        self.loggingCam = self.pluginPrefs.get("LogChoiceCam", False)
        self.loggingMon = self.pluginPrefs.get("LogChoiceMon", False)
        self.loggingWs = self.pluginPrefs.get("LogChoiceWs", False)
        self.loggingSd = self.pluginPrefs.get("LogChoiceSd", False)
        self.loggingTherm = self.pluginPrefs.get("LogChoiceTherm", False)
        self.processLastSeen = self.pluginPrefs.get("ProcessLastSeen", False)
        self.delForgotten = self.pluginPrefs.get("DeleteForgotten", False)
        self.snapshotPath = self.pluginPrefs.get("SnapshotPath", "")
        self.healthyHome = self.pluginPrefs.get("HealthyHome", False)
        self.weather = self.pluginPrefs.get("Weather", False)
        self.smoke = self.pluginPrefs.get("Smoke", False)
        self.therm = self.pluginPrefs.get("Therm", False)
        self.defaultBoostTemp = self.pluginPrefs.get("DefaultBoostTemp", 20)
        self.useAppDefault = self.pluginPrefs.get("UseAppDefault", False)
        self.defaultBoostHours = self.pluginPrefs.get("DefaultBoostHours", 1)
        self.limescaleProtect = self.pluginPrefs.get("LimescaleProtect", False)
        self.limeTime = self.pluginPrefs.get("LimeTime", 600)
        self.lpComplete = True
        self.lpInProgress = False
        self.lpClosePhase = False
        self.lpRequest = False
        self.lpCloseTime = 0
        self.syncCamNames = self.pluginPrefs.get("SyncCameraNames", False)
        self.syncMonNames = self.pluginPrefs.get("SyncMonitorNames", False)
        self.syncDetNames = self.pluginPrefs.get("SyncDetectorNames", False)
        self.showDirectionInNotes = self.pluginPrefs.get("ShowDirectionInNotes", False)
        self.showAirQualityInNotes = self.pluginPrefs.get("ShowAirQualityInNotes", False)
        self.includeFavourites = self.pluginPrefs.get("IncludeFavourites", False)
        self.showSetpointInNotes = self.pluginPrefs.get("ShowSetpointInNotes", False)
        self.debugEnabled = self.pluginPrefs.get("debugEnabled", False)
        self.timeout = 20
        self.tUnits = ("C","F")
        self.rUnits = (" mm", " in")
        self.wUnits = (" kph", " mph", " ms", " Bft", " knot")
        self.bftThreshold = (1, 5, 11, 19, 28, 38, 49, 61, 74, 88,102, 117)
        self.wConversion = (1, 0.621371, 0.277778, 0, 0.539957)
        self.pUnits = (" mbar", " inHg", "mmHg")
        self.stationMac = ""
        self.homeId = ""
        self.camUrl = {}
        self.camId = {}
        self.detId = {}
        self.personId = {}
        self.currentPersonsList = []
        self.trvList = []
        self.scheduleList = []
        self.scheduleIdList = []
        self.max_schedules = 0
        self.scheduleInUse = ""
        self.rooms = {}
        self.zones = {}
        self.zoneName = ""
        self.locations = {}
        self.commsOK = True
        self.weatherOK = True
        self.thermOK = True
        self.changeMade = False
        self.retriesC = 0
        self.retriesH = 0
        self.retriesW = 0
        self.retriesT = 0
        self.retriesX = 0
        self.lastUpdateTimeHH = 0
        self.lastUpdateTimeWS = 0
        self.lastUpdateTimeTherm = 0
        self.lastUpdateTimeHouse = 0
        self.lastCO2 = {}
        self.lastRain = 0
        self.lastRainH = 0
        self.lastRainD = 0
        self.rainNeedsReset = True
        self.lastDetectorEventTime = 0
        self.unreachableM = {}
        self.unreachableW = {}
        self.unreachableWCount = {}
        self.unreachableT = {}
        self.unreachableTCount = {}
        self.openList = {}
        self.inhibitPeriod = 1200


    ########################################
    def __del__(self):
        indigo.PluginBase.__del__(self)
        
    ########################################
    def startup(self):
        indigo.server.log("Starting Netatmo Multi plugin")
        self.firstTime = True

    def deviceStartComm(self, dev):
        dev.stateListOrDisplayStateIdChanged()
        return

    def shutdown(self):
        indigo.server.log("Stopping Netatmo Multi plugin")
        if self.saveTokens:
            self.pluginPrefs["accessToken"] = self.accessToken
            self.pluginPrefs["refreshToken"] = self.refreshToken
            self.pluginPrefs["expiration"] = self.expiration
        else:
            self.pluginPrefs["accessToken"] = ""
            self.pluginPrefs["refreshToken"] = ""
            self.pluginPrefs["expiration"] = 0
        

    ########################################
    def runConcurrentThread(self):
        while not (self.presence or self.welcome or self.weather or self.healthyHome or self.smoke or self.therm):
            self.sleep(1)
        if self.firstTime:
            self.userName = self.pluginPrefs.get("userName", "None")
            self.userPass = self.pluginPrefs.get("userPass", "None")
            self.clientId = self.pluginPrefs.get("clientId", "None")
            self.clientSecret = self.pluginPrefs.get("clientSecret", "None")
            self.accessToken = self.pluginPrefs.get("accessToken", "")
            self.refreshToken = self.pluginPrefs.get("refreshToken", "")
            self.expiration = int(self.pluginPrefs.get("expiration", 0))
            self.saveTokens = self.pluginPrefs.get("saveTokens", False)
            self.presence = self.pluginPrefs.get("Presence", False)
            self.welcome = self.pluginPrefs.get("Welcome", False)
            self.pollFreq = float(self.pluginPrefs.get("netatmoFreq", 1))
            self.pollF = int(self.pollFreq * 60)
            self.loggingCam = self.pluginPrefs.get("LogChoiceCam", False)
            self.loggingMon = self.pluginPrefs.get("LogChoiceMon", False)
            self.loggingWs = self.pluginPrefs.get("LogChoiceWs", False)
            self.loggingSd = self.pluginPrefs.get("LogChoiceSd", False)
            self.loggingTherm = self.pluginPrefs.get("LogChoiceTherm", False)
            self.processLastSeen = self.pluginPrefs.get("ProcessLastSeen", False)
            self.delForgotten = self.pluginPrefs.get("DeleteForgotten", False)
            self.snapshotPath = self.pluginPrefs.get("SnapshotPath", "")
            self.healthyHome = self.pluginPrefs.get("HealthyHome", False)
            self.weather = self.pluginPrefs.get("Weather", False)
            self.smoke = self.pluginPrefs.get("Smoke", False)
            self.therm = self.pluginPrefs.get("Therm", False)
            self.defaultBoostTemp = self.pluginPrefs.get("DefaultBoostTemp", 20)
            self.useAppDefault = self.pluginPrefs.get("UseAppDefault", False)
            self.defaultBoostHours = self.pluginPrefs.get("DefaultBoostHours", 1)
            self.defaultBoostPeriod = 60
            self.limescaleProtect = self.pluginPrefs.get("LimescaleProtect", False)
            self.limeTime = self.pluginPrefs.get("LimeTime", 10)
            self.lpComplete = False
            self.lpInProgress = False
            self.lpClosePhase = False
            self.lpRequest = False
            self.lpCloseTime = 0    
            self.max_schedules = 0
            self.syncCamNames = self.pluginPrefs.get("SyncCameraNames", False)
            self.syncMonNames = self.pluginPrefs.get("SyncMonitorNames", False)
            self.syncDetNames = self.pluginPrefs.get("SyncDetectorNames", False)
            self.showDirectionInNotes = self.pluginPrefs.get("ShowDirectionInNotes", False)
            self.showAirQualityInNotes = self.pluginPrefs.get("ShowAirQualityInNotes", False)
            self.includeFavourites = self.pluginPrefs.get("IncludeFavourites", False)
            self.tpTimeoutCount = 0
            self.tpErrorCount = 0
            self.showSetpointInNotes = self.pluginPrefs.get("ShowSetpointInNotes", False)
            self.debugEnabled = self.pluginPrefs.get("debugEnabled", False)
            self.createDevices()
            self.firstTime = False

        indigo.server.log("********************************************************************")
        indigo.server.log("Starting Netatmo Multi monitoring thread")
        if self.saveTokens:
            indigo.server.log("Access and Refresh Tokens will be saved on shutdown")
        else:
            indigo.server.log("New Access and Refresh Tokens will be requested on startup")
        if self.presence:
            indigo.server.log("Presence camera(s) will be polled")
        if self.welcome:
            indigo.server.log("Welcome camera(s) will be polled")
            indigo.server.log(" - Camera polling set to %s seconds" % self.pollF)
            if self.processLastSeen:
                indigo.server.log(" - Last Seen variables will be created/updated")
            else:
                indigo.server.log(" - Last Seen variables will not be created/updated")
            if self.delForgotten:
                indigo.server.log(" - Persons forgotten in Netatmo app will be deleted")
            else:
                indigo.server.log(" - Persons forgotten in Netatmo app will not be deleted")
            if self.snapshotPath != "":
                indigo.server.log(" - Snapshot folder is %s" % self.snapshotPath)
            if self.loggingCam:
                indigo.server.log(" - Camera message logging is on")
        if self.healthyHome:
            indigo.server.log("Healthy Home air quality monitor(s) will be polled")
            if self.loggingMon:
                indigo.server.log(" - Monitor message logging is on")
        if self.weather:
            indigo.server.log("Weather station(s) will be polled")
            if self.includeFavourites:
                indigo.server.log(" - Favourite third party stations will also be polled")
            if self.loggingWs:
                indigo.server.log(" - Weather station message logging is on")
        if self.smoke:
            indigo.server.log("Smoke detector(s) will be polled")
            if self.loggingSd:
                indigo.server.log(" - Smoke detector message logging is on")
        if self.therm:
            indigo.server.log("Thermostat(s) will be polled")
            if self.limescaleProtect:
                indigo.server.log(" - Limescale protection will be scheduled weekly")
                indigo.server.log("   - TRV cycle time is %s minutes" % self.limeTime)
            else:
                indigo.server.log(" - Limescale protection schedule disabled")
            if self.loggingTherm:
                indigo.server.log(" - Thermostat message logging is on")
        indigo.server.log("********************************************************************")

        try:
            while True:
                if self.expiration < time.time():   # Token should be renewed
                    status, detail = self.refresh(self.clientId, self.clientSecret, self.refreshToken)
                    if status == "error" and self.commsOK:
                        indigo.server.log("runConcurrentThread() - authentication failed.  Will keep trying.", isError=True)
                        self.commsOK = False
                    elif status != "error" and self.commsOK == False:
                        indigo.server.log("runConcurrentThread() - authentication now OK")
                        self.commsOK = True
                if self.commsOK:
                    self.getUpdate()
                else:
                    if self.welcome or self.presence:
                        device = None
                        for dev in indigo.devices.iter("self"):
                            if dev.deviceTypeId == "netatmoWelcome":
                                device = indigo.devices[dev.name]
                        if device != None:
                            device.updateStateOnServer("status", value = "off")
                    self.sleep(600)
                    self.commsOK = True             
                self.sleep(self.pollF)
                
        except self.StopThread:
            self.shutdown()


    ######################################
    # Called when user prefs are changed   
            
    def closedPrefsConfigUi(self, valuesDict, userCancelled):
        # If the user saved preferences, update logging parameters
        if userCancelled == False:
            oldSaveTokens = self.saveTokens
            self.saveTokens = valuesDict.get("saveTokens", False)
            if self.saveTokens != oldSaveTokens:
                if self.saveTokens:
                    indigo.server.log("Access and Refresh Tokens will be saved on shutdown")
                else:
                    indigo.server.log("New Access and Refresh Tokens will be requested on startup")
                    self.pluginPrefs["accessToken"] = ""
                    self.pluginPrefs["refreshToken"] = ""
                    self.pluginPrefs["expiration"] = 0
            oldLoggingCam = self.loggingCam
            self.loggingCam = valuesDict.get("LogChoiceCam", False)
            if self.loggingCam != oldLoggingCam:
                if self.loggingCam:
                    indigo.server.log("Logging all Welcome camera messages to Event Log")
                else:
                    indigo.server.log("Welcome camera message logging is off")
            oldSyncCam = self.syncCamNames
            self.syncCamNames = valuesDict.get("SyncCameraNames", False)
            if self.syncCamNames != oldSyncCam:
                if self.syncCamNames:
                    indigo.server.log("Camera name changes will be synced to Indigo device names")
                else:
                    indigo.server.log("Camera name changes will not be synced to Indigo device names")
            oldLoggingMon = self.loggingMon
            self.loggingMon = valuesDict.get("LogChoiceMon", False)
            if self.loggingMon != oldLoggingMon:
                if self.loggingMon:
                    indigo.server.log("Logging all Healthy Home messages to Event Log")
                else:
                    indigo.server.log("Healthy Home message logging is off")
            oldSyncMon = self.syncMonNames
            self.syncMonNames = valuesDict.get("SyncMonitorNames", False)
            if self.syncMonNames != oldSyncMon:
                if self.syncMonNames:
                    indigo.server.log("Healthy Home name changes will be synced to Indigo device names")
                else:
                    indigo.server.log("Healthy Home name changes will not be synced to Indigo device names")
            oldLoggingWs = self.loggingWs
            self.loggingWs = valuesDict.get("LogChoiceWs", False)
            if self.loggingWs != oldLoggingWs:
                if self.loggingWs:
                    indigo.server.log("Logging all weather station messages to Event Log")
                else:
                    indigo.server.log("Weather station message logging is off")
            oldLoggingSd = self.loggingSd
            self.loggingSd = valuesDict.get("LogChoiceSd", False)
            if self.loggingSd != oldLoggingSd:
                if self.loggingSd:
                    indigo.server.log("Logging all smoke detector messages to Event Log")
                else:
                    indigo.server.log("Smoke Detector message logging is off")
            oldLoggingTherm = self.loggingTherm
            self.loggingTherm = valuesDict.get("LogChoiceTherm", False)
            if self.loggingTherm != oldLoggingTherm:
                if self.loggingTherm:
                    indigo.server.log("Logging all thermostat messages to Event Log")
                else:
                    indigo.server.log("Thermostat message logging is off")
            oldLast = self.processLastSeen  
            self.processLastSeen = valuesDict.get("ProcessLastSeen", False)
            if self.processLastSeen != oldLast:
                if self.processLastSeen:
                    indigo.server.log("Last Seen variables will be created/updated")
                else:
                    indigo.server.log("Last Seen variables will not be created/updated")
            oldDel = self.delForgotten
            self.delForgotten = valuesDict.get("DeleteForgotten", False)
            if self.delForgotten != oldDel:
                if self.delForgotten:
                    indigo.server.log("Persons forgotten in Netatmo app will be deleted")
                else:
                    indigo.server.log("Persons forgotten in Netatmo app will not be deleted")
            oldSp = self.snapshotPath
            self.snapshotPath = valuesDict.get("SnapshotPath", "")
            if self.snapshotPath != oldSp:
                if self.snapshotPath == "":
                    indigo.server.log("No snapshot path specified", isError=True)
                else:
                    indigo.server.log("New snapshot folder path is %s" % self.snapshotPath)
            oldPr = self.presence
            self.presence = valuesDict.get("Presence", False)
            if self.presence != oldPr:
                self.accessToken = ""
                if self.presence:
                    indigo.server.log("Presence Camera(s) will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo camera device ***")
                else:
                    indigo.server.log("Presence Camera(s) will not be polled") 
            oldWc = self.welcome
            self.welcome = valuesDict.get("Welcome", False)
            if self.welcome != oldWc:
                self.accessToken = ""
                if self.welcome:
                    indigo.server.log("Welcome Camera(s) will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo camera device ***")
                else:
                    indigo.server.log("Welcome Camera(s) will not be polled") 
            oldHh = self.healthyHome
            self.healthyHome = valuesDict.get("HealthyHome", False)
            if self.healthyHome != oldHh:
                self.accessToken = ""
                if self.healthyHome:
                    indigo.server.log("Healthy Home monitor(s) will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo monitor device ***")
                else:
                    indigo.server.log("Healthy Home monitor(s) will not be polled")
            oldWs = self.weather
            self.weather = valuesDict.get("Weather", False)
            if self.weather != oldWs:
                self.accessToken = ""
                if self.weather:
                    indigo.server.log("Weather station will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo weather device ***")
                else:
                    indigo.server.log("Weather station(s) will not be polled")
            oldIf = self.includeFavourites
            self.includeFavourites = valuesDict.get("IncludeFavourites", False)
            if self.includeFavourites != oldIf:
                if self.includeFavourites:
                    indigo.server.log("Favourite third party stations will also be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create new Indigo weather device(s) ***")
                else:
                    indigo.server.log("Favourite third party stations will not be polled")
            oldSd = self.showDirectionInNotes
            self.showDirectionInNotes = valuesDict.get("ShowDirectionInNotes", False)
            if self.showDirectionInNotes != oldSd:
                if self.showDirectionInNotes:
                    indigo.server.log("Wind direction will be shown in Indigo Home Window Notes field")
                else:
                    indigo.server.log("Wind direction will not be shown in Indigo Home Window Notes field")
            oldAq = self.showAirQualityInNotes
            self.showAirQualityInNotes = valuesDict.get("ShowAirQualityInNotes", False)
            if self.showAirQualityInNotes != oldAq:
                if self.showAirQualityInNotes:
                    indigo.server.log("Air quality will be shown in Indigo Home Window Notes field")
                else:
                    indigo.server.log("Air quality will not be shown in Indigo Home Window Notes field")
            oldSmoke = self.smoke
            self.smoke = valuesDict.get("Smoke", False)
            if self.smoke != oldSmoke:
                self.accessToken = ""
                if self.smoke:
                    indigo.server.log("Smoke detector(s) will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo smoke detector device ***")
                else:
                    indigo.server.log("Smoke detector(s) will not be polled")
            oldSyncDet = self.syncDetNames
            self.syncDetNames = valuesDict.get("SyncDetectorNames", False)
            if self.syncDetNames != oldSyncDet:
                if self.syncDetNames:
                    indigo.server.log("Smoke detector name changes will be synced to Indigo device names")
                else:
                    indigo.server.log("Smoke detector name changes will not be synced to Indigo device names")
            oldTherm = self.therm
            self.therm = valuesDict.get("Therm", False)
            if self.therm != oldTherm:
                self.accessToken = ""
                if self.therm:
                    indigo.server.log("Thermostat(s) will be polled")
                    if not self.firstTime:
                        indigo.server.log("*** Please restart the plugin to create a new Indigo Thermostat device ***")
                else:
                    indigo.server.log("Thermostat(s) will not be polled")
            oldDefault = self.useAppDefault
            self.useAppDefault = valuesDict.get("UseAppDefault", False)
            if self.useAppDefault != oldDefault:
                if self.useAppDefault:
                    indigo.server.log("App default period will be used for overrides")
                else:
                    indigo.server.log("Plugin default period will be used for overrides")
            oldSpin = self.showSetpointInNotes
            self.showSetpointInNotes = valuesDict.get("ShowSetpointInNotes", False)
            if self.showSetpointInNotes != oldSpin:
                if self.showSetpointInNotes:
                    indigo.server.log("Setpoints will be shown in Indigo Home Window Notes field")
                else:
                    indigo.server.log("Setpoints will not be shown in Indigo Home Window Notes field")
            oldLime = self.limescaleProtect
            self.limescaleProtect = valuesDict.get("LimescaleProtect", False)
            if self.limescaleProtect != oldLime:
                if self.limescaleProtect:
                    indigo.server.log("Limescale protection will be scheduled weekly")
                else:
                    indigo.server.log("Limescale protection schedule disabled")
            oldLimeTime = self.limeTime
            self.limeTime = valuesDict.get("LimeTime", 600)
            if self.limeTime != oldLimeTime:
                indigo.server.log("Limescale protection cycle time is %s minutes" % self.limeTime)
            oldDebug = self.debugEnabled
            self.debugEnabled = valuesDict.get("debugEnabled", False)
            if self.debugEnabled != oldDebug:
                if self.debugEnabled:
                    indigo.server.log("Debug messages will be written to Event Log")
                else:
                    indigo.server.log("Debug messages will not be written to Event Log")


        
    ########################################
    # Netatmo specific functions
    
    def createDevices(self):
        if self.userName == "None":
            indigo.server.log("Missing User Name")   
        if self.userPass == "None":
            indigo.server.log("Missing User Password")
        if self.clientId == "None":
            indigo.server.log("Missing Client ID")   
        if self.clientSecret == "None":
            indigo.server.log("Missing Client Secret")
        if not(self.presence or self.welcome or self.healthyHome or self.weather or self.smoke or self.therm):
            indigo.server.log("Please enable at least one Netatmo device in Config", isError=True)
        if (self.accessToken == "") or (self.refreshToken == "") or (self.expiration < time.time()):
            indigo.server.log("Renewing expired tokens")
            status, detail = self.authenticate(self.userName, self.userPass, self.clientId, self.clientSecret)
            if status == "error" and self.commsOK:
                indigo.server.log("Authentication failed in createDevices", isError=True)
                indigo.server.log(detail, isError=True)
                self.commsOK = False
                #return
            elif status == "OK" and self.commsOK == False:
                indigo.server.log("Authentication in createDevices now OK")
                self.commsOK = True
        else:
            indigo.server.log("Current tokens are valid; authentication not required")
        
        if self.commsOK:
            if self.welcome or self.presence:        
                if not ("Netatmo" in indigo.variables.folders):
                    indigo.variables.folder.create("Netatmo")   
                self.netatmoFolderId = indigo.variables.folders.getId("Netatmo")
                max_cameras = 0
                payload = {'access_token': self.accessToken,'size': 5,}
                try:
                    response = requests.post("https://api.netatmo.com/api/gethomedata", data=payload, timeout=self.timeout)
                    self.sleep(2)   # Try to avoid 'No cameras' error
                    if self.loggingCam:
                        indigo.server.log("Camera Data Status Code:\n"+str(response.status_code))
                        indigo.server.log("Camera Data:\n"+str(response.text))
                        indigo.server.log("Camera Data Reponse:\n"+str(response.raise_for_status))
                    if response.status_code == 403:  # This check doesn't work
                        self.refresh(self.clientId, self.clientSecret, self.refreshToken)
                    elif response.status_code == 502:
                        indigo.server.log("No response from Netatmo Welcome API server", isError=True)
                        return
                    else:
                        try:
                            dataJ = response.json()["body"]
                            if self.loggingCam:
                                indigo.server.log("Camera Data:\n"+str(dataJ))
                            self.homeId = dataJ["homes"][0]["id"]
                            max_cameras = len(dataJ["homes"][0]["cameras"])
                            self.sleep(5)   # Try to avoid 'No cameras' error
                        except:
                            indigo.server.log("Netatmo data error", isError=True)
                    #indigo.server.log("Max Cams = "+str(max_cameras))
                    if max_cameras == 0:
                        indigo.server.log("No cameras detected")
                    for cam in range(0, max_cameras):
                        camName = dataJ["homes"][0]["cameras"][cam]["name"]
                        camType = dataJ["homes"][0]["cameras"][cam]["type"]
                        camStatus = dataJ["homes"][0]["cameras"][cam]["status"]
                        self.camId[cam] = dataJ["homes"][0]["cameras"][cam]["id"]
                        if camStatus == "on":
                            self.camUrl[self.camId[cam]] = str(dataJ["homes"][0]["cameras"][cam]["vpn_url"])
                        else:
                            self.camUrl[self.camId[cam]] = ""
                        device = None
                        for dev in indigo.devices.iter("self"):
                            if dev.address == self.camId[cam]:
                                device = indigo.devices[dev.name]
                        if device == None:
                            indigo.server.log("Creating Netatmo camera device for %s" % (camName))
                            nameC = "%s" % (camName)
                            device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=self.camId[cam], name=nameC, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoWelcome", props={})
                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Camera device creation error: "+self.getErrorText(error.response.text), isError=True)
                except requests.Timeout as error:
                   indigo.server.log("Camera device creation timeout error", isError=True)

            if self.smoke:        
                payload = {'access_token': self.accessToken,'size': 5,}
                try:
                    response = requests.post("https://api.netatmo.com/api/gethomedata", data=payload, timeout=self.timeout)
                    if self.loggingSd:
                        indigo.server.log("Smoke Detector Data Status Code:\n"+str(response.status_code))
                        indigo.server.log("Smoke Detector Data:\n"+str(response.text))
                        indigo.server.log("Smoke Detector Data Reponse:\n"+str(response.raise_for_status))
                    if response.status_code == 403:  # This check doesn't work
                        self.refresh(self.clientId, self.clientSecret, self.refreshToken)
                    elif response.status_code == 502:
                        indigo.server.log("No response from Netatmo API server", isError=True)
                        return
                    else:
                        dataJ = response.json()["body"]
                        if self.loggingSd:
                            indigo.server.log("Smoke Detector Data:\n"+str(dataJ))
                        self.homeId = dataJ["homes"][0]["id"]
                        max_detectors = len(dataJ["homes"][0]["smokedetectors"])
                        self.sleep(2)
                    #indigo.server.log("Max Detectors = "+str(max_detectors))
                    for det in range(0, max_detectors):
                        detName = dataJ["homes"][0]["smokedetectors"][det]["name"]
                        self.detId[det] = dataJ["homes"][0]["smokedetectors"][det]["id"]
                        detAdd = "SD%s" % det
                        device = None
                        for dev in indigo.devices.iter("self"):
                            if dev.address == detAdd:
                                device = indigo.devices[dev.name]
                        if device == None:
                            indigo.server.log("Creating Netatmo smoke detector device for %s" % (detName))
                            device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=detAdd, name=detName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoSmokeDetector", props={})
                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Smoke detector device creation error: "+self.getErrorText(error.response.text), isError=True)
                except requests.Timeout as error:
                   indigo.server.log("Smoke detector device creation timeout error", isError=True)
                   
            if self.healthyHome:
                payload = {'access_token': self.accessToken}
                try:
                    response = requests.post("https://api.netatmo.com/api/gethomecoachsdata", params=payload, timeout=self.timeout)
                    response.raise_for_status()
                    dataJ = response.json()["body"]
                    max_monitors = len(dataJ["devices"])
                    for mon in range(0, max_monitors):
                        monName = dataJ["devices"][mon]["station_name"]
                        monAdd = "HH%s" % mon
                        device = None
                        for dev in indigo.devices.iter("self"):
                            if dev.address == monAdd:
                                device = indigo.devices[dev.name]
                        if device == None:
                            indigo.server.log("Creating Netatmo monitor device for %s" % (monName))
                            nameM = "%s Air Monitor" % (monName)
                            device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=monAdd, name=nameM, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoHome", props={})         
                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Healthy Home device creation error: "+self.getErrorText(error.response.text), isError=True)
                except requests.Timeout as error:
                   indigo.server.log("Healthy Home device creation timeout error", isError=True)

            if self.weather:
                payload = {'access_token': self.accessToken}
                try:
                    response = requests.post("https://api.netatmo.com/api/getstationsdata", params=payload, timeout=self.timeout)
                    response.raise_for_status()
                    if self.loggingWs:
                        indigo.server.log("Weather Station Data for Device Creation:\n"+str(response.json()))
                    dataJ = response.json()["body"]
                    max_stations = len(dataJ["devices"])
                    for station in range(0, max_stations):
                        try:
                            favourite = dataJ["devices"][station]["favorite"]
                            if favourite == True:
                                continue
                        except:
                            homeName = dataJ["devices"][station]["home_name"]
                            self.stationMac = dataJ["devices"][station]["_id"]
                            try:
                                modName = dataJ["devices"][station]["module_name"]
                            except:
                                indigo.server.log("Module has no name.  Please name module in Netatmo app, delete any devices created by the plugin then restart the plugin.", isError=True)
                            stnAdd = "WS-"+str(station)
                            self.lastCO2[stnAdd] = 0
                            device = None
                            for dev in indigo.devices.iter("self"):
                                if dev.address == stnAdd:
                                    device = indigo.devices[dev.name]
                            if device == None:
                                indigo.server.log("Creating Netatmo weather device for %s" % (modName))
                                nameM = "%s Air Monitor" % (modName)
                                device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=stnAdd, name=nameM, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoBaseStation", props={})
                                device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                            max_modules = len(dataJ["devices"][station]["modules"])
                            for module in range(0, max_modules):
                                modType = dataJ["devices"][station]["modules"][module]["type"]
                                homeName = dataJ["devices"][station]["home_name"]
                                modName = dataJ["devices"][station]["modules"][module]["module_name"]
                                #modAdd = "WSM-"+str(module + 1)
                                modAdd = "WS%sM%s" % (str(station), str(module + 1))
                                if modType == "NAModule1":
                                    #Outdoor Module
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo weather device for %s" % (modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoOutModule", props={"SupportsBatteryLevel":True})
                                        device.updateStateImageOnServer(indigo.kStateImageSel.TemperatureSensor)
                                elif modType == "NAModule2":
                                    #Wind Module
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo weather device for %s" % (modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoWindGauge", props={"SupportsBatteryLevel":True})
                                        device.updateStateImageOnServer(indigo.kStateImageSel.FanOff)
                                elif modType == "NAModule3":
                                    #Rain Module
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo weather device for %s" % (modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoRainGauge", props={"SupportsBatteryLevel":True})
                                        device.updateStateImageOnServer(indigo.kStateImageSel.HumiditySensor)
                                elif modType == "NAModule4":
                                    #Additional Indoor Module
                                    self.lastCO2[modAdd] = 0
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo weather device for %s" % (modName))
                                        nameM = "%s Air Monitor" % (modName)
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=nameM, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoAddIndoorModule", props={"SupportsBatteryLevel":True})
                                        device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                                else:
                                    indigo.server.log("Cannot create device: unknown module type %s" % modType, isError=True)
                                
                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Weather device creation error: "+self.getErrorText(error.response.text), isError=True)
                   
                except requests.Timeout as error:
                   indigo.server.log("Weather device creation timeout error", isError=True)

            if self.weather and self.includeFavourites:
                dataJ = ""
                qparams = (
                    ('access_token', self.accessToken),
                    ('device_id', self.stationMac),
                    ('get_favorites', 'true'),
                )
                try:
                    response = requests.post("https://api.netatmo.com/api/getstationsdata", params=qparams, timeout=self.timeout)
                    response.raise_for_status()
                    dataJ = response.json()["body"]
                    max_stations = len(dataJ["devices"])
                    for station in range(0, max_stations):
                        stationMac = dataJ["devices"][station]["_id"]
                        if stationMac != self.stationMac:
                            try:
                                homeName = dataJ["devices"][station]["home_name"]
                            except:
                                homeName = dataJ["devices"][station]["station_name"]
                            sep = " ("
                            homeName = homeName.split(sep, 1)[0]
                            max_modules = len(dataJ["devices"][station]["modules"])
                            for module in range(0, max_modules):
                                modType = dataJ["devices"][station]["modules"][module]["type"]
                                modAdd = dataJ["devices"][station]["modules"][module]["_id"]
                                if modType == "NAModule1":
                                    #Outdoor Module
                                    modName = "Outdoor"
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo third party weather device for %s" % (homeName+" "+modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=homeName+" "+modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoOutModule")
                                        device.updateStateImageOnServer(indigo.kStateImageSel.TemperatureSensor)
                                elif modType == "NAModule2":
                                    #Wind Module
                                    modName = "Wind"
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo third party third party weather device for %s" % (homeName+" "+modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=homeName+" "+modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoWindGauge")
                                        device.updateStateImageOnServer(indigo.kStateImageSel.FanOff)
                                elif modType == "NAModule3":
                                    #Rain Module
                                    modName = "Rain"
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                    if device == None:
                                        indigo.server.log("Creating Netatmo third party weather device for %s" % (homeName+" "+modName))
                                        device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modAdd, name=homeName+" "+modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoRainGauge")
                                        device.updateStateImageOnServer(indigo.kStateImageSel.HumiditySensor)
                                else:
                                    indigo.server.log("Cannot create third party weather device: unknown module type %s" % modType, isError=True)                       
                                
                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Third party weather device creation error: "+self.getErrorText(error.response.text), isError=True)
                   
                except requests.Timeout as error:
                   indigo.server.log("Third party weather device creation timeout error", isError=True)

            if self.therm:
                payload = {'access_token': self.accessToken, 'gateway_types': 'NAPlug'}
                try:
                    response = requests.post("https://api.netatmo.com/api/homesdata", params=payload, timeout=self.timeout)
                    response.raise_for_status()
                    dataH = response.json()["body"]
                    if self.loggingTherm:
                        indigo.server.log("Thermostat Homes Data:\n"+str(dataH))
                    if len(dataH["homes"]) > 2:
                        indigo.server.log("This plugin does not support more than one home", isError=True)
                    self.homeId = dataH["homes"][0]["id"]
                    if self.debugEnabled:
                        indigo.server.log("Retrieving room data...")
                    max_rooms = len(dataH["homes"][0]["rooms"])
                    if self.debugEnabled:
                        indigo.server.log("Max rooms = %s" % max_rooms)
                    for r in range (0, max_rooms):
                        roomId = dataH["homes"][0]["rooms"][r]["id"]
                        roomName = dataH["homes"][0]["rooms"][r]["name"]
                        if self.debugEnabled:
                            indigo.server.log("Processing room %s" % roomName)
                        self.rooms[roomId] = roomName
                    if self.debugEnabled:
                        indigo.server.log("Retrieving schedule data...")
                    self.max_schedules = len(dataH["homes"][0]["schedules"])
                    if self.debugEnabled:
                        indigo.server.log("Max schedules = %s" % self.max_schedules)
                    for sched in range(0, self.max_schedules):
                        if self.debugEnabled:
                            indigo.server.log("Processing schedule %s" % dataH["homes"][0]["schedules"][sched]["name"])
                        self.scheduleList.insert(sched, dataH["homes"][0]["schedules"][sched]["name"])
                        self.scheduleIdList.insert(sched, dataH["homes"][0]["schedules"][sched]["id"])
                        try:
                            # 'selected' key is only present for selected schedule
                            selected = dataH["homes"][0]["schedules"][sched]["selected"]
                            self.scheduleInUse = dataH["homes"][0]["schedules"][sched]["name"]
                            if self.debugEnabled:
                                indigo.server.log("Selected schedule = %s" % dataH["homes"][0]["schedules"][sched]["name"])
                        except:
                            pass
                    max_mods = len(dataH["homes"][0]["modules"])
                    for m in range(0, max_mods):
                        modType = dataH["homes"][0]["modules"][m]["type"]
                        if (modType == "NATherm1") or (modType == "NRV"):
                            modId = dataH["homes"][0]["modules"][m]["id"]
                            modRoomId = dataH["homes"][0]["modules"][m]["room_id"]
                            modRoomName = self.rooms[modRoomId]
                            self.locations[modId] = modRoomId
                            if modType == "NATherm1":
                                modName = "Netatmo Stat "+str(m)+" ("+modRoomName+")"
                            elif modType == "NRV":
                                modName = "Netatmo TRV "+str(m)+" ("+modRoomName+")"
                            device = None
                            for dev in indigo.devices.iter("self"):
                                if dev.address == modId:
                                    device = indigo.devices[dev.name]
                            if device == None:
                                indigo.server.log("Creating Netatmo thermostat device for %s" % (modName))
                                props={"SupportsCoolSetpoint":False, "SupportsHvacFanMode":False}                                               
                                device = indigo.device.create(protocol=indigo.kProtocol.Plugin, address=modId, name=modName, pluginId="com.racarter.indigoplugin.netatmo-welcome", deviceTypeId="netatmoTherm", props={"SupportsBatteryLevel":True, "SupportsCoolSetpoint":False, "SupportsHvacFanMode":False})                 

                except requests.exceptions.HTTPError as error:
                   indigo.server.log("Thermostat device creation error: "+self.getErrorText(error.response.text), isError=True)
                   
                except requests.Timeout as error:
                   indigo.server.log("Thermostat device creation timeout error", isError=True)
                   

    def getUpdate(self):

        if self.accessToken == "" or self.refreshToken == "":
            status, detail = self.authenticate(self.userName, self.userPass, self.clientId, self.clientSecret)
            if status == 'error' and self.commsOK:
                indigo.server.log("Authentication failed in getUpdate():", isError=True)
                indigo.server.log(detail, isError=True)
                self.commsOK = False
            elif status == "OK" and self.commsOK == False:
                indigo.server.log("Authentication in getUpdate() now OK")
                self.commsOK = True

        if self.commsOK:
            if self.welcome or self.presence or self.smoke:      
                payload = {'access_token': self.accessToken, 'size': 20,}
                try:
                    response = requests.post("https://api.netatmo.com/api/gethomedata", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    if self.welcome or self.presence:
                        self.updateIndigoCam(response.json()["body"])
                    if self.smoke:
                        self.updateIndigoSmoke(response.json()["body"])
                    self.retriesC = 0        
                except:
                    self.retriesC += 1
                    if self.retriesC == 10:
                        indigo.server.log("Camera/Smoke Detector update error after ten attempts: ", isError=True)
                
            if self.healthyHome and (time.time() - self.lastUpdateTimeHH > 300):
                payload = {'access_token': self.accessToken}
                try:
                    response = requests.post("https://api.netatmo.com/api/gethomecoachsdata", params=payload, timeout=self.timeout)
                    response.raise_for_status()
                    dataJ = response.json()["body"]
                    self.updateIndigoMon(response.json()["body"])
                    self.retriesH = 0
                except:
                    self.retriesH += 1
                    if self.retriesH == 10:
                        indigo.server.log("Healthy Home update error after ten attempts", isError=True)

            if self.weather and (time.time() - self.lastUpdateTimeWS > 600):
                # Fresh readings should now be available.  (Weather station only uploads data every 10 minutes)
                payload = {'access_token': self.accessToken}
                try:
                    response = requests.post("https://api.netatmo.com/api/getstationsdata", params=payload, timeout=self.timeout)
                    response.raise_for_status()
                    dataJ = response.json()["body"]
                    self.updateIndigoWeather(response.json()["body"])
                    self.retriesW = 0
                except:
                    self.retriesW += 1
                    if self.retriesW == 10:
                        indigo.server.log("Weather update error after ten attempts", isError=True)                    
                        
                if self.includeFavourites:
                    dataJ = ""
                    qparams = (
                        ('access_token', self.accessToken),
                        ('device_id', self.stationMac),
                        ('get_favorites', 'true'),
                    )
                    try:
                        response = requests.post("https://api.netatmo.com/api/getstationsdata", params=qparams, timeout=self.timeout)
                        response.raise_for_status()
                        self.tpTimeoutCount = 0
                        self.tpErrorCount = 0
                        dataJ = response.json()["body"]
                        self.updateThirdPartyWeather(response.json()["body"])
                                                   
                    except requests.Timeout as error:
                        self.tpTimeoutCount += 1
                        if self.tpTimeoutCount == 10:
                            indigo.server.log("Third party weather station timeout after ten attempts", isError=True)
                            
                    except:
                        self.tpErrorCount += 1
                        if self.tpErrorCount == 10:
                            indigo.server.log("Third party weather station update error after ten attempts", isError=True)
                    
            if self.therm and (time.time() - self.lastUpdateTimeTherm > 60):
                # Update Thermostat every minute (Thermostat only uploads data once per hour but it's useful to have status updates)
                self.getHouseUpdate()
                self.getThermUpdate()
                
            if self.therm and (self.limescaleProtect or self.lpRequest):
                thisDay = datetime.datetime.today().weekday()   #Sunday = 6
                thisHour = datetime.datetime.now().hour
                if (self.lpRequest == True):
                    self.limescaleProtectGo()
                elif (thisDay == 6) and (thisHour < 15) and (self.lpComplete == True):
                    self.lpComplete = False                
                elif (thisDay == 6) and (thisHour == 15) and (self.lpComplete == False):
                    self.limescaleProtectGo()
                    
            # Check for TRVs in limescale protection mode and open if necessary
            if len(self.openList) > 0:
                for k, v in self.openList.items():
                    if v < time.time():
                        self.trvOpen(k)
                        del self.openList[k]
                        self.sleep(2)
                                  

    def getThermUpdate(self):
        headers = { 
            'Authorization': 'Bearer ' + self.accessToken
        }
        payload = {
            'home_id': self.homeId
        }
        try:
            response = requests.post("https://api.netatmo.com/api/homestatus", params=payload, headers=headers, timeout=self.timeout)
            response.raise_for_status()
            dataT = response.json()["body"]
            self.updateIndigoTherm(dataT)
            self.retriesT = 0
            self.changeMade = False
        except:
            self.retriesT += 1
            if self.retriesT == 10:
                indigo.server.log("Thermostat/TRV update error after ten attempts", isError=True)


    def getHouseUpdate(self):
        payload = {'access_token': self.accessToken, 'gateway_types': 'NAPlug'}
        try:
            response = requests.post("https://api.netatmo.com/api/homesdata", params=payload, timeout=self.timeout)
            response.raise_for_status()
            dataX = response.json()["body"]
            self.updateIndigoHouse(dataX)
            self.retriesX = 0
        except:
            self.retriesX += 1
            if self.retriesX == 10:
                indigo.server.log("Netatmo house update error after ten attempts", isError=True) 

           
    def updateIndigoCam(self, dataJ):
        if self.loggingCam:
            indigo.server.log("Camera Data:\n"+str(dataJ))
        max_persons = len(dataJ["homes"][0]["persons"])
        home_count = 0
        self.currentPersonsList = []
        occ = "_Occupants"
        for pers in range(0, max_persons):
            try:
                try:
                    stage = "pseudo"
                    name = dataJ["homes"][0]["persons"][pers]["pseudo"]
                    name = name.replace(" ", "_")
                except:
                    # No value for 'pseudo' signifies person seen is unknown, so ignore when updating persons list.
                    continue
                stage = "id1"
                name_id = dataJ["homes"][0]["persons"][pers]["id"]
                stage = "out_of_sight"
                out = dataJ["homes"][0]["persons"][pers]["out_of_sight"]
                self.personId[name] = name_id
                if out:
                    status = "Away"
                else:
                    status = "Home"
                    home_count = home_count + 1
                    if self.loggingCam:
                        indigo.server.log(name+" is "+status)
                updateVar(name, value=status, folder=self.netatmoFolderId)
                self.currentPersonsList.append(name)
                if self.processLastSeen:
                    stage = "last_seen"
                    lastU = dataJ["homes"][0]["persons"][pers]["last_seen"]
                    if lastU > 0:
                        last = datetime.datetime.fromtimestamp(int(lastU)).strftime('%Y-%m-%d %H:%M:%S')
                    else:
                        last = "-"
                    nameLS = name+"_last_seen"
                    updateVar(nameLS, value=last, folder=self.netatmoFolderId)            
            except:
                e = sys.exc_info()[0]
                indigo.server.log("Cannot process %s, %s" % (name, e), isError=True)
                indigo.server.log("Stage = %s" % stage, isError=True) 

        if self.delForgotten:
            self.delForgottenPersons()
            
        if occ not in indigo.variables:
            indigo.variable.create(occ, value=str(home_count), folder=self.netatmoFolderId)
        else:
            indigo.variable.updateValue(occ, value=str(home_count))

        max_cameras = len(dataJ["homes"][0]["cameras"])
        for cam in range(0, max_cameras):
            try:
                stage = "status"
                camState = dataJ["homes"][0]["cameras"][cam]["status"]
                if camState == "disconnected":
                    camState = "off"
                stage = "sd_status"
                sdState = dataJ["homes"][0]["cameras"][cam]["sd_status"]
                stage = "alim_status"
                psuState = dataJ["homes"][0]["cameras"][cam]["alim_status"]
                stage = "name"
                camName = dataJ["homes"][0]["cameras"][cam]["name"]
                uCamName = camName.replace(" ", "_")
                stage = "id"
                camId = dataJ["homes"][0]["cameras"][cam]["id"]
                stage = "type"
                camType = dataJ["homes"][0]["cameras"][cam]["type"]
                stage = "url"
                surl = ""
                vurl = ""
                if camState == "on":
                    try:
                        self.camUrl[camId] = str(dataJ["homes"][0]["cameras"][cam]["vpn_url"])
                        surl = self.camUrl[camId]+"/live/snapshot_720.jpg"
                        vurl = self.camUrl[camId]+"/live/index_local.m3u8"
                    except:
                        # URL may not be sent for a short time after camera is switched on.
                        pass
                stage = "light"
                if camType == "NACamera":
                    stage = "NAC"
                    lightMode = "N/A"
                elif camType == "NOC":
                    stage = "NOC"
                    lightMode = dataJ["homes"][0]["cameras"][cam]["light_mode_status"]
                else:
                    indigo.server.log("Unknown camera type", isError=True)
                stage = "snap"
                snapName = "_snap_url_"+uCamName
                vidName = "_vid_url_"+uCamName
                updateVar(snapName, value=surl, folder=self.netatmoFolderId)
                updateVar(vidName, value=vurl, folder=self.netatmoFolderId)
                stage = "message"
                lastEvent, lastEventTime, camEventFound, lastEventPointer = self.checkEvent(dataJ, camId)
                #indigo.server.log(camName)
                #indigo.server.log(camEventFound)
                #indigo.server.log(lastEvent)
                #indigo.server.log(lastEventTime)
                #indigo.server.log(str(lastEventPointer))
                stage = "time"
                lastUpdateTime = time.strftime('%d-%b-%y %H:%M:%S')
                device = None
                for dev in indigo.devices.iter("self"):
                    if dev.address == camId:
                        device = indigo.devices[dev.name]
                if device != None:
                    stage = "camera_id"
                    if camEventFound == "Yes":
                        keyValueList = [
                            {'key':'status', 'value':camState},
                            {'key':'sd_status', 'value':sdState},
                            {'key':'psu_status', 'value':psuState},
                            {'key':'light_mode', 'value':lightMode},
                            {'key':'last_event', 'value':lastEvent},
                            {'key':'last_event_pointer', 'value':lastEventPointer},
                            {'key':'last_event_time', 'value':lastEventTime},
                            {'key':'last_update_time', 'value':lastUpdateTime},
                        ]
                    else:
                        keyValueList = [
                            {'key':'status', 'value':camState},
                            {'key':'sd_status', 'value':sdState},
                            {'key':'psu_status', 'value':psuState},
                            {'key':'light_mode', 'value':lightMode},
                            {'key':'last_update_time', 'value':lastUpdateTime},
                        ]
                    device.updateStatesOnServer(keyValueList)                             
                    if camState == "off":
                        device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                    else:
                        device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                    if self.syncCamNames:
                        camName = dataJ["homes"][0]["cameras"][cam]["name"]
                        if camName != device.name:
                            try:
                                device.name = camName
                                device.replaceOnServer()
                            except:
                                indigo.server.log("Cannot update %s name" % device.name, isError=True)
            except:
                e = sys.exc_info()[0]
                indigo.server.log("Camera %s update error: %s" % (camId, e), isError=True)
                indigo.server.log("Stage = %s" % stage, isError=True)  
            
            
    def updateIndigoSmoke(self, dataJ):
        if self.loggingSd and not self.loggingCam:
            indigo.server.log("Smoke Detector Data:\n"+str(dataJ))
        max_detectors = len(dataJ["homes"][0]["smokedetectors"])
        for det in range(0, max_detectors):
            try:
                detName = dataJ["homes"][0]["smokedetectors"][det]["name"]
                detAdd = "SD%s" % det
                lastUpdateTime = time.strftime('%d-%b-%y %H:%M:%S')
                device = None
                for dev in indigo.devices.iter("self"):
                    if dev.address == detAdd:
                        device = indigo.devices[dev.name]
                if device != None:
                    device.updateStateOnServer(key="last_update_time", value=lastUpdateTime)
                    for i in range(0, 10):
                        lastEventDeviceId = dataJ["homes"][0]["events"][i]["device_id"]
                        if self.detId[det] == lastEventDeviceId:
                            lastEventType = dataJ["homes"][0]["events"][i]["type"]
                            try:
                                lastEventSub = dataJ["homes"][0]["events"][i]["sub_type"]
                            except:
                                lastEventSub = "-"
                            lastEventRaw = dataJ["homes"][0]["events"][i]["message"]
                            lastEventTimeRaw = dataJ["homes"][0]["events"][i]["time"]
                            lastEvent = re.sub('<[^<]+?>', '', lastEventRaw)
                            lastEventTime = time.strftime('%d-%b-%y %H:%M:%S', time.localtime(lastEventTimeRaw))
                            if lastEventTimeRaw != self.lastDetectorEventTime:
                                indigo.server.log(lastEvent)
                                self.lastDetectorEventTime = lastEventTimeRaw 
                            if lastEventType == "smoke":
                                if lastEventSub == 1:
                                    status = "Alarm"
                                else:
                                    status = "OK"
                            elif lastEventType == "hush":
                                if lastEventSub == 1:
                                    status = "Hushed"
                                    device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                                else:
                                    status = "OK"
                                    device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                            elif lastEventType == "tampered":
                                if lastEventSub == 1:
                                    status = "Tamper"
                                    device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                                else:
                                    status = "OK"
                                    device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                            elif lastEventType == "detection_chamber_status":
                                if lastEventSub == 1:
                                    status = "Dusty"
                                else:
                                    status = "OK"
                            elif lastEventType == "battery_status":
                                if lastEventSub == 1:
                                    status = "VLowBatt"
                                else:
                                    status = "LowBatt"                            
                            else:
                                status = "OK"
                                device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                            keyValueList = [
                                {'key':'last_event', 'value':lastEvent},
                                {'key':'last_event_time', 'value':lastEventTime},
                                {'key':'last_event_type', 'value':lastEventType},
                                {'key':'last_event_subtype', 'value':lastEventSub},
                                {'key':'status', 'value':status},
                            ]
                            device.updateStatesOnServer(keyValueList)
                            break
                      
                    if self.syncDetNames:
                        detName = dataJ["homes"][0]["smokedetectors"][det]["name"]
                        if detName != device.name:
                            try:
                                device.name = detName
                                device.replaceOnServer()
                            except:
                                indigo.server.log("Cannot update %s name" % device.name, isError=True)
            except:
                e = sys.exc_info()[0]
                indigo.server.log("Smoke detector %s update error: %s" % (detAdd, e), isError=True)


    def updateIndigoMon(self, dataJ):
        if self.loggingMon:
            indigo.server.log("Healthy Home Data:\n"+str(dataJ))    
        max_monitors = len(dataJ["devices"])
        corfM = dataJ["user"]["administrative"]["unit"]
        for mon in range(0, max_monitors):
            monAdd = "HH%s" % mon
            device = None
            for dev in indigo.devices.iter("self"):
                if dev.address == monAdd:
                    device = indigo.devices[dev.name]
            # Test necessitated by Netatmo API change Nov 18.  No longer sends dashboard_data for unreachable devices.
            reachable = dataJ["devices"][mon]["reachable"]
            if reachable == False:
                if not self.unreachableM.get(monAdd, False):
                    indigo.server.log("Device %s is unreachable" % monAdd, isError=True)
                    self.unreachableM[monAdd] = True
                continue
            else:
                self.unreachableM[monAdd] = False
            try:
                dataK = dataJ["devices"][mon]
                try:
                    health = dataK["dashboard_data"]["health_idx"]
                except:
                    health = 5
                if health == 0:
                    status = "Healthy"
                elif health == 1:
                    status = "Fine"
                elif health == 2:
                    status = "Fair"
                elif health == 3:
                    status = "Poor"
                elif health == 4:
                    status = "Unhealthy"
                else:
                    status = "Unknown"
                # Temperature and pressure trends are not immediately available when
                #  a monitor is installed, and occasionally Noise data is missing,
                #  hence the 'try' tests.
                try:
                    dbg = "Noise"
                    noise = dataK["dashboard_data"]["Noise"]
                except:
                    noise = 0
                noiseUi = str(noise)+" dB"
                dbg = "Temperature"
                temperature = self.tempUnits(dataK["dashboard_data"]["Temperature"], corfM)
                dbg = "Pressure"
                pressure = dataK["dashboard_data"]["Pressure"]
                pressureUi = str(pressure)+" mBar"
                dbg = "Humidity"
                humidity = dataK["dashboard_data"]["Humidity"]
                humidityUi = str(humidity)+" %"
                dbg = "CO2"
                co2 = dataK["dashboard_data"]["CO2"]
                co2Ui = str(co2)+" ppm"
                dbg = "Min Temp"
                minTemp = self.tempUnits(dataK["dashboard_data"]["min_temp"], corfM)
                minTempUi = str(minTemp)+self.tUnits[corfM]
                dbg = "Min Temp Date"
                minTempDate = dataK["dashboard_data"]["date_min_temp"]
                minTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(minTempDate))
                dbg = "Max Temp"
                maxTemp = self.tempUnits(dataK["dashboard_data"]["max_temp"], corfM)
                maxTempUi = str(maxTemp)+self.tUnits[corfM]
                dbg = "Max Temp Date"
                maxTempDate = dataK["dashboard_data"]["date_max_temp"]
                maxTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(maxTempDate))
                dbg = "co2Cal"
                co2Cal = dataK["co2_calibrating"]
                if co2Cal:
                    co2CalS = "True"
                else:
                    co2CalS = "False"
                dbg = "Firmware"
                firmware = dataK["firmware"]
                dbg = "Last Upgrade"
                try:
                    lastUpgrade = dataK["last_upgrade"]
                    lastUpgradeF = time.strftime('%d-%b-%y %H:%M', time.localtime(lastUpgrade))
                except:
                    lastUpgradeF = "-"
                dbg = "WiFi"
                wifi = dataK["wifi_status"]
                dbg = "UTC"
                timestamp = dataK["dashboard_data"]["time_utc"]
                timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                self.lastUpdateTimeHH = timestamp
                dbg = "devUpdate1"
                if device != None:
                    dbg = "devUpdate2"
                    device.updateStateOnServer(key="Temperature", value=temperature, uiValue=str(temperature)+self.tUnits[corfM])
                    keyValueList = [
                        {'key':'Status', 'value':status},
                        {'key':'Health', 'value':health},
                        {'key':'Noise', 'value':noise, 'uiValue':noiseUi},
                        {'key':'Pressure', 'value':pressure, 'uiValue':pressureUi},
                        {'key':'Humidity', 'value':humidity, 'uiValue':humidityUi},
                        {'key':'CO2', 'value':co2, 'uiValue':co2Ui},
                        {'key':'CO2Calibrating', 'value':co2CalS},
                        {'key':'MinTemp', 'value':minTemp, 'uiValue':minTempUi},
                        {'key':'MinTempDate', 'value':minTempDateF},
                        {'key':'MaxTemp', 'value':maxTemp, 'uiValue':maxTempUi},
                        {'key':'MaxTempDate', 'value':maxTempDateF},
                        {'key':'Firmware', 'value':firmware},
                        {'key':'LastUpgrade', 'value':lastUpgradeF},
                        {'key':'WiFiStatus', 'value':wifi},
                        {'key':'LastReading', 'value':timestampF},
                        {'key':'Reachable', 'value':reachable},
                    ]
                    dbg = "devUpdate3"
                    device.updateStatesOnServer(keyValueList)
                    dbg = "health"
                    if health > 2:
                        device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                    else:
                        device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                    if self.showAirQualityInNotes:
                        device.description = status
                        device.replaceOnServer()
                    elif device.description != "":
                        device.description = ""
                        device.replaceOnServer()
                    dbg = "syncNames"
                    if self.syncMonNames:
                        monName = dataJ["devices"][mon]["station_name"]+" Air Monitor"
                        if monName != device.name:
                            try:
                                device.name = monName
                                device.replaceOnServer()
                            except:
                                indigo.server.log("Cannot update %s name" % device.name, isError=True)
                    dbg = "Reachable processing"
                    self.unreachableM[monAdd+"a"] = False
                    self.errorCountHH = 0
                    device.setErrorStateOnServer(None)

            except (requests.Timeout, requests.exceptions.HTTPError) as error:
                if not self.unreachableM.get(monAdd+"a", False):
                    indigo.server.log(("Healthy Home %s update error type 1: " % monAdd)+self.getErrorText(error.response.text), isError=True)
                    device.setErrorStateOnServer("Error")
                    self.unreachableM[monAdd+"a"] = True

            except:
                # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                now = datetime.datetime.now()
                midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                seconds = (now - midnight).seconds
                if seconds > self.inhibitPeriod and not self.unreachableM.get(monAdd+"a", False):
                    e = sys.exc_info()[0]
                    indigo.server.log("Healthy Home %s update error type 2: %s, %s" % (monAdd, e, dbg), isError=True)
                    device.setErrorStateOnServer("Error")
                    self.unreachableM[monAdd+"a"] = True
            

    def updateIndigoWeather(self, dataJ):
        if self.loggingWs:
            indigo.server.log("Weather Station Data:\n"+str(dataJ))    
        max_stations = len(dataJ["devices"])
        for station in range(0, max_stations):
            if self.debugEnabled:
                indigo.server.log("Processing Weather Station %d" % station)
            try:
                favourite = dataJ["devices"][station]["favorite"]
                if favourite == True:
                    continue
            except:
                try:
                    if self.debugEnabled:
                        indigo.server.log("Processing Modules:")
                    dataK = dataJ["devices"][station]
                    dataL = dataJ["user"]["administrative"]
                    modType = dataK["type"]
                    homeName = dataK["home_name"]
                    modName = dataK["module_name"]
                    corfW = dataL["unit"]
                    tUnit = self.tUnits[dataL["unit"]]
                    rUnit = self.rUnits[dataL["unit"]]
                    wUnit = self.wUnits[dataL["windunit"]]
                    pUnit = self.pUnits[dataL["pressureunit"]]
                    wCF = self.wConversion[dataL["windunit"]]
                    if self.debugEnabled:
                        indigo.server.log("Processing %s %s" % (modName, modType))
                    stnAdd = "WS-"+str(station)
                    # Test necessitated by Netatmo API change Nov 18.  No longer sends dashboard_data for unreachable devices.
                    reachable = dataK["reachable"]
                    if reachable == False:
                        if not self.unreachableW.get(modName, False):
                            self.unreachableWCount[modName] += 1
                            if self.unreachableWCount.get(modName, 0) == 10:
                                indigo.server.log("Device %s is unreachable after ten attempts" % modName, isError=True)
                                self.unreachableW[modName] = True
                        continue
                    else:
                        self.unreachableWCount[modName] = 0
                        self.unreachableW[modName] = False
                    # Base Station (noise, temp, mintemp+date, maxtemp+date, humidity, pressure, co2, wifi, timestamp)
                    # Temperature and pressure trends are not immediately available when
                    #  a monitor is installed, and occasionally Noise data is missing,
                    #  hence the 'try' tests.
                    if self.debugEnabled:
                        indigo.server.log(" Processing Noise")
                    try:
                        noise = dataK["dashboard_data"]["Noise"]
                    except:
                        noise = 0
                    noiseUi = str(noise)+" dB"
                    if self.debugEnabled:
                        indigo.server.log(" Processing Temp")
                    temperature = self.tempUnits(dataK["dashboard_data"]["Temperature"], corfW)
                    if self.debugEnabled:
                        indigo.server.log(" Processing Temp Trend")
                    try:
                        tempTrend = dataK["dashboard_data"]["temp_trend"]
                    except:
                        tempTrend = ""
                    if self.debugEnabled:
                        indigo.server.log(" Processing Pressure")
                    pressure = dataK["dashboard_data"]["Pressure"]
                    pressureUi = str(pressure)+" "+pUnit
                    absPressure = dataK["dashboard_data"]["AbsolutePressure"]
                    absPressureUi = str(absPressure)+" "+pUnit
                    if self.debugEnabled:
                        indigo.server.log(" Processing Humidity")
                    humidity = dataK["dashboard_data"]["Humidity"]
                    humidityUi = str(humidity)+" %"
                    if self.debugEnabled:
                        indigo.server.log(" Processing CO2")
                    try:
                        co2 = dataK["dashboard_data"]["CO2"]
                        self.lastCO2[stnAdd] = co2
                    except:
                        co2 = self.lastCO2[stnAdd]
                    co2Ui = str(co2)+" ppm"
                    if self.debugEnabled:
                        indigo.server.log(" Processing CO2 Cal")
                    co2Cal = dataK["co2_calibrating"]
                    if co2Cal:
                        co2CalS = "True"
                    else:
                        co2CalS = "False"
                    if self.debugEnabled:
                        indigo.server.log(" Processing Min/Max")
                    #minTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["min_temp"]))
                    minTemp = self.tempUnits(dataK["dashboard_data"]["min_temp"], corfW)
                    minTempUi = str(minTemp)+tUnit
                    minTempDate = dataK["dashboard_data"]["date_min_temp"]
                    minTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(minTempDate))
                    #maxTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["max_temp"]))
                    maxTemp = self.tempUnits(dataK["dashboard_data"]["max_temp"], corfW)
                    maxTempUi = str(maxTemp)+tUnit
                    maxTempDate = dataK["dashboard_data"]["date_max_temp"]
                    maxTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(maxTempDate))
                    firmware = dataK["firmware"]
                    try:
                        lastUpgrade = dataK["last_upgrade"]
                        lastUpgradeF = time.strftime('%d-%b-%y %H:%M', time.localtime(lastUpgrade))
                    except:
                        lastUpgradeF = "N/A"
                    wifi = dataK["wifi_status"]
                    macAddress = dataK["_id"]      
                    if self.debugEnabled:
                        indigo.server.log(" Processing Timestamp")
                    timestamp = dataK["dashboard_data"]["time_utc"]
                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                    self.lastUpdateTimeWS = timestamp
                    if self.debugEnabled:
                        indigo.server.log(" Finding weather device")
                    device = None
                    for dev in indigo.devices.iter("self"):
                        if dev.address == stnAdd:
                            device = indigo.devices[dev.name]
                            devChanged = self.readingChanged(dev, timestampF)
                    if device != None:
                        device.updateStateOnServer(key="MAC", value=macAddress, uiValue=macAddress)
                        if self.debugEnabled:
                            indigo.server.log(" - Updating %s" % device.name)
                    elif self.debugEnabled:
                        indigo.server.log(" Device not found!")
                    if device != None and devChanged:
                        if self.debugEnabled:
                            indigo.server.log("  Processing device temperature update")
                        device.updateStateOnServer(key="Temperature", value=temperature, uiValue=str(temperature)+tUnit)
                        keyValueList = [
                            {'key':'Noise', 'value':noise, 'uiValue':noiseUi},
                            {'key':'TemperatureTrend', 'value':tempTrend},
                            {'key':'Pressure', 'value':pressure, 'uiValue':pressureUi},
                            {'key':'AbsolutePressure', 'value':absPressure, 'uiValue':absPressureUi},
                            {'key':'Humidity', 'value':humidity, 'uiValue':humidityUi},
                            {'key':'CO2', 'value':co2, 'uiValue':co2Ui},
                            {'key':'CO2Calibrating', 'value':co2CalS},
                            {'key':'MinTemp', 'value':minTemp, 'uiValue':minTempUi},
                            {'key':'MinTempDate', 'value':minTempDateF},
                            {'key':'MaxTemp', 'value':maxTemp, 'uiValue':maxTempUi},
                            {'key':'MaxTempDate', 'value':maxTempDateF},
                            {'key':'Firmware', 'value':firmware},
                            {'key':'LastUpgrade', 'value':lastUpgradeF},
                            {'key':'WiFiStatus', 'value':wifi},
                            {'key':'LastReading', 'value':timestampF},
                            {'key':'Reachable', 'value':reachable},
                            {'key':'MAC', 'value':macAddress},
                        ]
                        if self.debugEnabled:
                            indigo.server.log("  Processing rest of device updates")
                        device.updateStatesOnServer(keyValueList)
                        if self.debugEnabled:
                            indigo.server.log("  Processing device state icon")                    
                        if co2 > 1200:
                            device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                        else:
                            device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)

                    # Process Modules:
                    # NAModule1 = Outdoor (temp, mintemp+date, maxtemp+date, humidity, pressure, ptrend, radio, battery, timestamp)
                    # NAModule2 = Wind (strength, angle, gust strength, gust angle, last hour, radio, battery, timestamp)
                    # NAModule3 = Rain (past hour, past 24h, radio, battery, timestamp)
                    # NAModule4 = Additional Indoor (as per base station - but no noise or pressure, and radio instead of wifi)
                    max_modules = len(dataJ["devices"][station]["modules"])
                    for module in range(0, max_modules):
                        try:
                            homeName = dataJ["devices"][station]["home_name"]
                        except:
                            homeName = dataJ["devices"][station]["station_name"]
                        dataK = dataJ["devices"][station]["modules"][module]
                        modType = dataK["type"]
                        modName = dataK["module_name"]
                        if self.debugEnabled:
                            indigo.server.log("Processing %s %s" % (modName, modType))
                        #Debug code to list dictionary items/values to Event Log:
                        #for k, v in dataK.iteritems():
                        #   indigo.server.log(str(v), str(k))
                        #modAdd = "WSM-"+str(module + 1)
                        modAdd = "WS%sM%s" % (str(station), str(module + 1))
                        # Test necessitated by Netatmo API change Nov 18.  No longer sends dashboard_data for unreachable devices.
                        reachable = dataK["reachable"]
                        if reachable == False:
                            device = None
                            for dev in indigo.devices.iter("self"):
                                if dev.address == modAdd:
                                    device = indigo.devices[dev.name]
                            if device != None:
                                device.updateStateOnServer(key="Reachable", value=reachable)    
                                device.setErrorStateOnServer("Error")
                                if self.unreachableW.get(device.name, False) == False:
                                    self.unreachableWCount[device.name] += 1
                                    if self.unreachableWCount.get(device.name, 0) == 10:
                                        indigo.server.log("Device %s is unreachable after ten attempts" % device.name, isError=True)
                                        self.unreachableW[device.name] = True
                        else:
                            if modType == "NAModule1":
                                # Outdoor Module
                                try:
                                    tempC = dataK["dashboard_data"]["Temperature"]
                                    temperature = self.tempUnits(dataK["dashboard_data"]["Temperature"], corfW)
                                    try:
                                        tempTrend = dataK["dashboard_data"]["temp_trend"]
                                    except:
                                        tempTrend = ""
                                    humidity = dataK["dashboard_data"]["Humidity"]
                                    humidityUi = str(humidity)+" %"
                                    dewpoint = self.tempUnits(tempC - ((100 - float(humidity)) / 5), corfW)
                                    dewpointUi = str(dewpoint)+tUnit
                                    #minTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["min_temp"]))
                                    minTemp = self.tempUnits(dataK["dashboard_data"]["min_temp"], corfW)
                                    minTempUi = str(minTemp)+tUnit
                                    minTempDate = dataK["dashboard_data"]["date_min_temp"]
                                    minTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(minTempDate))
                                    #maxTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["max_temp"]))
                                    maxTemp = self.tempUnits(dataK["dashboard_data"]["max_temp"], corfW)
                                    maxTempUi = str(maxTemp)+tUnit
                                    maxTempDate = dataK["dashboard_data"]["date_max_temp"]
                                    maxTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(maxTempDate))
                                    firmware = dataK["firmware"]
                                    radio = dataK["rf_status"]
                                    battery = dataK["battery_percent"]
                                    macAddress = dataK["_id"] 
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        if self.debugEnabled:
                                            indigo.server.log(" - Updating %s" % device.name)
                                        device.updateStateOnServer(key="Temperature", value=temperature, uiValue=str(temperature)+tUnit)
                                        keyValueList = [
                                            {'key':'TemperatureTrend', 'value':tempTrend},
                                            {'key':'Humidity', 'value':humidity, 'uiValue':humidityUi},
                                            {'key':'Dewpoint', 'value':dewpoint, 'uiValue':dewpointUi},
                                            {'key':'MinTemp', 'value':minTemp, 'uiValue':minTempUi},
                                            {'key':'MinTempDate', 'value':minTempDateF},
                                            {'key':'MaxTemp', 'value':maxTemp, 'uiValue':maxTempUi},
                                            {'key':'MaxTempDate', 'value':maxTempDateF},
                                            {'key':'batteryLevel', 'value':battery},
                                            {'key':'Firmware', 'value':firmware},
                                            {'key':'RadioStatus', 'value':radio},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Outdoor module %s update error: %s" % (modAdd, e), isError=True)
                                        indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log("Device reachable is %s" % reachable)

                            elif modType == "NAModule2":
                                # Wind Gauge
                                try:
                                    dbg = "Strength"
                                    if wCF > 0:
                                        wStrength = int(round(dataK["dashboard_data"]["WindStrength"] * wCF))
                                    else:
                                        # Beaufort Scale selected
                                        wStrength = self.kphToBft(dataK["dashboard_data"]["WindStrength"])
                                    dbg = "Wangle"
                                    wAngle = dataK["dashboard_data"]["WindAngle"]
                                    wDirection = self.degToCompass(wAngle)
                                    dbg = "Gstrength"
                                    gStrength = int(round(dataK["dashboard_data"]["GustStrength"] * wCF))
                                    gStrengthUi = str(gStrength)+wUnit
                                    dbg = "Gangle"
                                    gAngle = dataK["dashboard_data"]["GustAngle"]
                                    gDirection = self.degToCompass(gAngle)
                                    dbg = "Mstrength"
                                    wMax = int(round(dataK["dashboard_data"]["max_wind_str"] * wCF))
                                    wMaxUi = str(wMax)+wUnit
                                    dbg = "Mdate"
                                    wMaxDate = dataK["dashboard_data"]["date_max_wind_str"]
                                    wMaxDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(wMaxDate))
                                    dbg = "Firmware"
                                    firmware = dataK["firmware"]
                                    dbg = "Radio"
                                    radio = dataK["rf_status"]
                                    dbg = "Battery"
                                    battery = dataK["battery_percent"]
                                    dbg = "UTC"
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    macAddress = dataK["_id"] 
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        if self.debugEnabled:
                                            indigo.server.log(" - Updating %s" % device.name)
                                        device.updateStateOnServer(key="WindStrength", value=wStrength, uiValue=str(wStrength)+wUnit)
                                        keyValueList = [
                                            {'key':'WindAngle', 'value':wAngle},
                                            {'key':'WindDirection', 'value':wDirection},
                                            {'key':'MaxWindStrength', 'value':wMax, 'uiValue':wMaxUi},
                                            {'key':'MaxWindDate', 'value':wMaxDateF},
                                            {'key':'GustStrength', 'value':gStrength, 'uiValue':gStrengthUi},
                                            {'key':'GustAngle', 'value':gAngle},
                                            {'key':'GustDirection', 'value':gDirection},
                                            {'key':'batteryLevel', 'value':battery},
                                            {'key':'Firmware', 'value':firmware},
                                            {'key':'RadioStatus', 'value':radio},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                        if self.showDirectionInNotes:
                                            device.description = wDirection
                                            device.replaceOnServer()
                                        elif device.description != "":
                                            device.description = ""
                                            device.replaceOnServer()
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Wind gauge %s update error: %s, %s" % (modAdd, e, dbg), isError=True)
                                        #indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log(str(dataK))
                                        indigo.server.log("Device reachable is %s" % reachable)

                            elif modType == "NAModule3":
                                # Rain Gauge
                                try:
                                    try:
                                        rain = float(dataK["dashboard_data"]["Rain"])
                                        self.lastRain = rain
                                    except:
                                        rain = self.lastRain
                                    try:
                                        rainH = float(dataK["dashboard_data"]["sum_rain_1"])
                                        self.lastRainH = rainH
                                    except:
                                        rainH = self.lastRainH
                                    newRain = 0
                                    try:
                                        rainD = float(dataK["dashboard_data"]["sum_rain_24"])
                                        if rainD > self.lastRainD:
                                            newRain = rainD - self.lastRainD
                                        self.lastRainD = rainD
                                    except:
                                        rainD = self.lastRainD
                                    rainUnits = str(' \u339C'.encode('utf-8'))
                                    if dataL["unit"] == 1:
                                        #Convert mm to inches
                                        rainUnits = '"'
                                        rain = rain * 0.0393701
                                        newRain = newRain * 0.0393701
                                        rainH = rainH * 0.0393701
                                        rainD = rainD * 0.0393701
                                    rainDUi = str(round(rainD, 1))+rainUnits
                                    rainHUi = str(round(rainH, 1))+rainUnits
                                    firmware = dataK["firmware"]
                                    radio = dataK["rf_status"]
                                    battery = dataK["battery_percent"]
                                    macAddress = dataK["_id"] 
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        if self.debugEnabled:
                                            indigo.server.log(" - Updating %s" % device.name)
                                        try:
                                            rainM = device.states["RainThisMonth"]
                                        except:
                                            rainM = rainD
                                        thisHour = datetime.datetime.now().hour
                                        thisDay = datetime.datetime.now().day
                                        if (thisDay == 1) and (thisHour == 0) and self.rainNeedsReset:
                                            rainM = 0
                                            self.rainNeedsReset = False
                                        else:
                                            rainM = rainM + newRain
                                        rainMUi = str(round(rainM, 1))+rainUnits
                                        if (thisDay == 1) and (thisHour == 1) and not self.rainNeedsReset:
                                            self.rainNeedsReset = True
                                        device.updateStateOnServer(key="Rain", value=rain, uiValue=str(rain)+rUnit)
                                        keyValueList = [
                                            {'key':'RainLastHour', 'value':rainH, 'uiValue':rainHUi},
                                            {'key':'RainLastDay', 'value':rainD, 'uiValue':rainDUi},
                                            {'key':'RainThisMonth', 'value':rainM, 'uiValue':rainMUi},
                                            {'key':'batteryLevel', 'value':battery},
                                            {'key':'Firmware', 'value':firmware},
                                            {'key':'RadioStatus', 'value':radio},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        f = sys.exc_info()[1]
                                        indigo.server.log("Rain gauge %s update error: %s %s" % (modAdd, e, f), isError=True)
                                        indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log("Device reachable is %s" % reachable)
                    
                            elif modType == "NAModule4":
                                # Additional Indoor Module
                                try:
                                    temperature = self.tempUnits(dataK["dashboard_data"]["Temperature"], corfW)
                                    try:
                                        tempTrend = dataK["dashboard_data"]["temp_trend"]
                                    except:
                                        tempTrend = ""
                                    humidity = dataK["dashboard_data"]["Humidity"]
                                    humidityUi = str(humidity)+" %"
                                    try:
                                        co2 = dataK["dashboard_data"]["CO2"]
                                        self.lastCO2[modAdd] = co2
                                    except:
                                        co2 = self.lastCO2[modAdd]
                                    co2Ui = str(co2)+" ppm"
                                    minTemp = self.tempUnits(dataK["dashboard_data"]["min_temp"], corfW)
                                    minTempUi = str(minTemp)+tUnit
                                    minTempDate = dataK["dashboard_data"]["date_min_temp"]
                                    minTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(minTempDate))
                                    maxTemp = self.tempUnits(dataK["dashboard_data"]["max_temp"], corfW)
                                    maxTempUi = str(maxTemp)+tUnit
                                    maxTempDate = dataK["dashboard_data"]["date_max_temp"]
                                    maxTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(maxTempDate))
                                    firmware = dataK["firmware"]
                                    radio = dataK["rf_status"]
                                    battery = dataK["battery_percent"]
                                    macAddress = dataK["_id"] 
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        if self.debugEnabled:
                                            indigo.server.log(" - Updating %s" % device.name)
                                        # ***This code was required to fix some devices not showing battery level bar
                                        #localPropsCopy = device.pluginProps
                                        #localPropsCopy.update({"SupportsBatteryLevel":True})
                                        #device.replacePluginPropsOnServer(localPropsCopy)
                                        # ***
                                        device.updateStateOnServer(key="Temperature", value=temperature, uiValue=str(temperature)+tUnit)
                                        keyValueList = [
                                            {'key':'TemperatureTrend', 'value':tempTrend},
                                            {'key':'Humidity', 'value':humidity, 'uiValue':humidityUi},
                                            {'key':'CO2', 'value':co2, 'uiValue':co2Ui},
                                            {'key':'MinTemp', 'value':minTemp, 'uiValue':minTempUi},
                                            {'key':'MinTempDate', 'value':minTempDateF},
                                            {'key':'MaxTemp', 'value':maxTemp, 'uiValue':maxTempUi},
                                            {'key':'MaxTempDate', 'value':maxTempDateF},
                                            {'key':'batteryLevel', 'value':battery},
                                            {'key':'Firmware', 'value':firmware},
                                            {'key':'RadioStatus', 'value':radio},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                        if co2 > 1200:
                                            device.updateStateImageOnServer(indigo.kStateImageSel.SensorOff)
                                        else:
                                            device.updateStateImageOnServer(indigo.kStateImageSel.SensorOn)
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Indoor module %s update error: %s" % (modAdd, e), isError=True)
                                        indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log("Device reachable is %s" % reachable)
                  
                            else:
                                indigo.server.log("Weather update: unknown module type %s" % modType, isError=True)
                        if not self.weatherOK:
                            self.weatherOK = True
                            indigo.server.log("Weather Station update fault cleared")
                        
                except (requests.Timeout, requests.exceptions.HTTPError) as error:
                    if self.weatherOK:
                        indigo.server.log("Weather Station update error: "+self.getErrorText(error.response.text), isError=True)
                        self.weatherOK = False
                    
                except:
                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                    now = datetime.datetime.now()
                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                    seconds = (now - midnight).seconds
                    if self.weatherOK and seconds > self.inhibitPeriod:
                        e = sys.exc_info()[0]
                        f = sys.exc_info()[1]
                        indigo.server.log("Weather station %s update error: %s %s" % (stnAdd, e, f), isError=True)
                        indigo.server.log("Device reachable is %s" % reachable)
                        self.weatherOK = False 


    def updateThirdPartyWeather(self, dataJ):
        if self.loggingWs:
            indigo.server.log("Third Party Weather Station Data:\n"+str(dataJ))    
        max_stations = len(dataJ["devices"])
        tUnit = "C"
        pUnit = "mBar"
        for station in range(0, max_stations):
            stationMac = dataJ["devices"][station]["_id"]
            if stationMac != self.stationMac:
                try:
                    dataK = dataJ["devices"][station]
                    dataL = dataJ["user"]["administrative"]
                    modType = dataK["type"]
                    try:    
                        homeName = dataK["home_name"]
                    except:
                        homeName = dataK["station_name"]
                    sep = " ("
                    homeName = homeName.split(sep, 1)[0]
                    corfW = dataL["unit"]
                    tUnit = self.tUnits[dataL["unit"]]
                    rUnit = self.rUnits[dataL["unit"]]
                    wUnit = self.wUnits[dataL["windunit"]]
                    pUnit = self.pUnits[dataL["pressureunit"]]
                    wCF = self.wConversion[dataL["windunit"]]
                    # Process Modules:
                    # NAModule1 = Outdoor (temp, mintemp+date, maxtemp+date, humidity, pressure, ptrend, radio, battery, timestamp)
                    # NAModule2 = Wind (strength, angle, gust strength, gust angle, last hour, radio, battery, timestamp)
                    # NAModule3 = Rain (past hour, past 24h, radio, battery, timestamp)
                    max_modules = len(dataJ["devices"][station]["modules"])
                    for module in range(0, max_modules):
                        dataK = dataJ["devices"][station]["modules"][module]
                        modType = dataK["type"]
                        if self.debugEnabled:
                            indigo.server.log("Processing %s %s" % (homeName, modType))
                        #Debug code to list dictionary items/values to Event Log:
                        #for k, v in dataK.iteritems():
                        #   indigo.server.log(str(v), str(k))
                        modAdd = dataJ["devices"][station]["modules"][module]["_id"]
                        # Test necessitated by Netatmo API change Nov 18.  No longer sends dashboard_data for unreachable devices.
                        reachable = dataK["reachable"]
                        if reachable == False:
                            device = None
                            for dev in indigo.devices.iter("self"):
                                if dev.address == modAdd:
                                    device = indigo.devices[dev.name]
                            if device != None:
                                device.updateStateOnServer(key="Reachable", value=reachable)    
                                device.setErrorStateOnServer("Error")
                                if self.unreachableW.get(device.name, False) == False:
                                    self.unreachableWCount[device.name] += 1
                                    if self.unreachableWCount.get(device.name, 0) == 10:
                                        indigo.server.log("Device %s is unreachable after ten attempts" % device.name, isError=True)
                                        self.unreachableW[device.name] = True
                            elif self.debugEnabled:
                                indigo.server.log(" Device not found!")
                        else:
                            if modType == "NAModule1":
                                # Outdoor Module
                                try:
                                    tempC = dataK["dashboard_data"]["Temperature"]
                                    temperature = self.tempUnits(dataK["dashboard_data"]["Temperature"], corfW)
                                    try:
                                        tempTrend = dataK["dashboard_data"]["temp_trend"]
                                    except:
                                        tempTrend = ""
                                    humidity = dataK["dashboard_data"]["Humidity"]
                                    humidityUi = str(humidity)+" %"
                                    dewpoint = self.tempUnits(tempC - ((100 - float(humidity)) / 5), corfW)
                                    dewpointUi = str(dewpoint)+tUnit
                                    #minTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["min_temp"]))
                                    minTemp = self.tempUnits(dataK["dashboard_data"]["min_temp"], corfW)
                                    minTempUi = str(minTemp)+tUnit
                                    minTempDate = dataK["dashboard_data"]["date_min_temp"]
                                    minTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(minTempDate))
                                    #maxTemp = "{0:0.1f}".format(float(dataK["dashboard_data"]["max_temp"]))
                                    maxTemp = self.tempUnits(dataK["dashboard_data"]["max_temp"], corfW)
                                    maxTempUi = str(maxTemp)+tUnit
                                    maxTempDate = dataK["dashboard_data"]["date_max_temp"]
                                    maxTempDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(maxTempDate))
                                    macAddress = dataK["_id"] 
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        device.updateStateOnServer(key="Temperature", value=temperature, uiValue=str(temperature)+tUnit)
                                        keyValueList = [
                                            {'key':'TemperatureTrend', 'value':tempTrend},
                                            {'key':'Humidity', 'value':humidity, 'uiValue':humidityUi},
                                            {'key':'Dewpoint', 'value':dewpoint, 'uiValue':dewpointUi},
                                            {'key':'MinTemp', 'value':minTemp, 'uiValue':minTempUi},
                                            {'key':'MinTempDate', 'value':minTempDateF},
                                            {'key':'MaxTemp', 'value':maxTemp, 'uiValue':maxTempUi},
                                            {'key':'MaxTempDate', 'value':maxTempDateF},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Outdoor module %s update error: %s" % (modAdd, e), isError=True)
                                        indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log("Device reachable is %s" % reachable)

                            elif modType == "NAModule2":
                                # Wind Gauge
                                try:
                                    dbg = "Strength"
                                    if wCF > 0:
                                        wStrength = int(round(dataK["dashboard_data"]["WindStrength"] * wCF))
                                    else:
                                        # Beaufort Scale selected
                                        wStrength = self.kphToBft(dataK["dashboard_data"]["WindStrength"])
                                    dbg = "Wangle"
                                    wAngle = dataK["dashboard_data"]["WindAngle"]
                                    wDirection = self.degToCompass(wAngle)
                                    dbg = "Gstrength"
                                    gStrength = int(round(dataK["dashboard_data"]["GustStrength"] * wCF))
                                    gStrengthUi = str(gStrength)+wUnit
                                    dbg = "Gangle"
                                    gAngle = dataK["dashboard_data"]["GustAngle"]
                                    gDirection = self.degToCompass(gAngle)
                                    dbg = "Mstrength"
                                    wMax = int(round(dataK["dashboard_data"]["max_wind_str"] * wCF))
                                    wMaxUi = str(wMax)+wUnit
                                    dbg = "Mdate"
                                    wMaxDate = dataK["dashboard_data"]["date_max_wind_str"]
                                    wMaxDateF = time.strftime('%d-%b-%y %H:%M', time.localtime(wMaxDate))
                                    dbg = "UTC"
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    macAddress = dataK["_id"] 
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        device.updateStateOnServer(key="WindStrength", value=wStrength, uiValue=str(wStrength)+wUnit)
                                        keyValueList = [
                                            {'key':'WindAngle', 'value':wAngle},
                                            {'key':'WindDirection', 'value':wDirection},
                                            {'key':'MaxWindStrength', 'value':wMax, 'uiValue':wMaxUi},
                                            {'key':'MaxWindDate', 'value':wMaxDateF},
                                            {'key':'GustStrength', 'value':gStrength, 'uiValue':gStrengthUi},
                                            {'key':'GustAngle', 'value':gAngle},
                                            {'key':'GustDirection', 'value':gDirection},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                        if self.showDirectionInNotes:
                                            device.description = wDirection
                                            device.replaceOnServer()
                                        elif device.description != "":
                                            device.description = ""
                                            device.replaceOnServer()
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Wind gauge %s update error: %s, %s" % (modAdd, e, dbg), isError=True)
                                        #indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log(str(dataK))
                                        indigo.server.log("Device reachable is %s" % reachable)
    
                            elif modType == "NAModule3":
                                # Rain Gauge
                                try:
                                    try:
                                        rain = float(dataK["dashboard_data"]["Rain"])
                                        self.lastRain = rain
                                    except:
                                        rain = self.lastRain
                                    try:
                                        rainH = float(dataK["dashboard_data"]["sum_rain_1"])
                                        self.lastRainH = rainH
                                    except:
                                        rainH = self.lastRainH
                                    newRain = 0
                                    try:
                                        rainD = float(dataK["dashboard_data"]["sum_rain_24"])
                                        if rainD > self.lastRainD:
                                            newRain = rainD - self.lastRainD
                                        self.lastRainD = rainD
                                    except:
                                        rainD = self.lastRainD
                                    rainUnits = u' \u339C'.encode('utf-8')
                                    if dataL["unit"] == 1:
                                        #Convert mm to inches
                                        rainUnits = '"'
                                        rain = rain * 0.0393701
                                        newRain = newRain * 0.0393701
                                        rainH = rainH * 0.0393701
                                        rainD = rainD * 0.0393701
                                    rainDUi = str(round(rainD, 1))+rainUnits
                                    rainHUi = str(round(rainH, 1))+rainUnits
                                    macAddress = dataK["_id"] 
                                    timestamp = dataK["dashboard_data"]["time_utc"]
                                    timestampF = time.strftime('%d-%b-%y %H:%M', time.localtime(timestamp))
                                    device = None
                                    for dev in indigo.devices.iter("self"):
                                        if dev.address == modAdd:
                                            device = indigo.devices[dev.name]
                                            devChanged = self.readingChanged(dev, timestampF)
                                    if device == None and self.debugEnabled:
                                        indigo.server.log(" Device not found!")
                                    if device != None and devChanged:
                                        try:
                                            rainM = device.states["RainThisMonth"]
                                        except:
                                            rainM = rainD
                                        thisHour = datetime.datetime.now().hour
                                        thisDay = datetime.datetime.now().day
                                        if (thisDay == 1) and (thisHour == 0) and self.rainNeedsReset:
                                            rainM = 0
                                            self.rainNeedsReset = False
                                        else:
                                            rainM = rainM + newRain
                                        rainMUi = str(round(rainM, 1))+rainUnits
                                        if (thisDay == 1) and (thisHour == 1) and not self.rainNeedsReset:
                                            self.rainNeedsReset = True
                                        device.updateStateOnServer(key="Rain", value=rain, uiValue=str(rain)+rUnit)
                                        keyValueList = [
                                            {'key':'RainLastHour', 'value':rainH, 'uiValue':rainHUi},
                                            {'key':'RainLastDay', 'value':rainD, 'uiValue':rainDUi},
                                            {'key':'RainThisMonth', 'value':rainM, 'uiValue':rainMUi},
                                            {'key':'LastReading', 'value':timestampF},
                                            {'key':'Reachable', 'value':reachable},
                                            {'key':'MAC', 'value':macAddress},
                                        ]
                                        device.updateStatesOnServer(keyValueList)
                                        self.unreachableW[device.name] = False
                                        self.unreachableWCount[device.name] = 0
                                except:
                                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                                    now = datetime.datetime.now()
                                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                                    seconds = (now - midnight).seconds
                                    if seconds > self.inhibitPeriod and not self.unreachableM.get(modAdd+"a", False):
                                        e = sys.exc_info()[0]
                                        indigo.server.log("Rain gauge %s update error: %s" % (modAdd, e), isError=True)
                                        indigo.server.log(str(dataK["dashboard_data"]))
                                        indigo.server.log("Device reachable is %s" % reachable)
                      
                            else:
                                indigo.server.log("Third party weather update: unknown module type %s" % modType, isError=True)
                        if not self.weatherOK:
                            self.weatherOK = True
                            indigo.server.log("Third party weather station update fault cleared")
                        
                except (requests.Timeout, requests.exceptions.HTTPError) as error:
                    if self.weatherOK:
                        indigo.server.log("Third party weather station update error: "+self.getErrorText(error.response.text), isError=True)
                        self.weatherOK = False
                    
                except:
                    # Suppress errors when Netatmo servers sometimes omit key values in the first update after midnight.
                    now = datetime.datetime.now()
                    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
                    seconds = (now - midnight).seconds
                    if self.weatherOK and seconds > self.inhibitPeriod:
                        e = sys.exc_info()[0]
                        indigo.server.log("Third party weather station %s update error: %s" % (stationMac, e), isError=True)
                        indigo.server.log("Device reachable is %s" % reachable)
                        self.weatherOK = False 
                    
                                      
    def updateIndigoTherm(self, dataT):
        # Note that data is uploaded to Netatmo once per hour (according to the API documentation)
        if self.loggingTherm:
            indigo.server.log("Thermostat Home Status:\n"+str(dataT))
        max_modules = len(dataT["home"]["modules"])
        for m in range(0, max_modules):
            stage = "start"
            try:
                tType = dataT["home"]["modules"][m]["type"]
                if  (tType == "NATherm1") or (tType == "NRV"):
                    modId = dataT["home"]["modules"][m]["id"]
                    stage = "reachable"
                    reachable = dataT["home"]["modules"][m]["reachable"]
                    if reachable == False:
                        device = None
                        for dev in indigo.devices.iter("self"):
                            if dev.address == modId:
                                device = indigo.devices[dev.name]
                        if device != None:
                            device.updateStateOnServer(key="Reachable", value=reachable)
                            device.setErrorStateOnServer("Error")
                            if self.unreachableT.get(device.name, False) == False:
                                self.unreachableTCount[device.name] += 1
                                #indigo.server.log("Device %s is unreachable after %d attempts" % (device.name, self.unreachableTCount[device.name]))
                                if self.unreachableTCount.get(device.name, 0) == 20:
                                    indigo.server.log("Device %s is unreachable after 20 attempts" % device.name, isError=True)
                                    self.unreachableT[device.name] = True
                    else:
                        stage = "battery level"
                        try:
                            batteryLevel = dataT["home"]["modules"][m]["battery_level"]
                        except:
                            #Battery level data missing so set to some value to prevent loss of updates
                            batteryLevel = 3000
                        stage = "heat status"
                        if  (tType == "NATherm1"):
                            try:
                                preheat = dataT["home"]["modules"][m]["anticipating"]
                            except:
                                preheat = "Unavailable"
                            calling = dataT["home"]["modules"][m]["boiler_valve_comfort_boost"]
                            boilerStatus = str(dataT["home"]["modules"][m]["boiler_status"])
                            if boilerStatus == "True":
                                boilerStatusString = "On"
                            else:
                                boilerStatusString = "Off"
                            deviceType = "Thermostat"
                            batteryPercent = int((batteryLevel - 2800) / 13)
                            if batteryPercent > 100:
                                batteryPercent = 100
                        elif (tType == "NRV"):
                            deviceType = "TRV"
                            preheat = "N/A"
                            boilerStatusString = "N/A"
                            batteryPercent = int((batteryLevel - 2100) / 11)
                            if batteryPercent > 100:
                                batteryPercent = 100
                        else:
                            deviceType = ""
                            preheat = "N/A"
                        stage = "battery state"
                        batteryState = dataT["home"]["modules"][m]["battery_state"]
                        firmware = dataT["home"]["modules"][m]["firmware_revision"]
                        radio = dataT["home"]["modules"][m]["rf_strength"]
                        roomId = self.locations[modId]
                        max_rooms = len(dataT["home"]["rooms"])
                        for r in range(0, max_rooms):
                            stage = "rooms"
                            if dataT["home"]["rooms"][r]["id"] == roomId:
                                stage = "room temps"
                                temp = dataT["home"]["rooms"][r]["therm_measured_temperature"]
                                intTemp = int(math.floor(temp))
                                roundTemp = round(temp, 1)
                                setpoint = dataT["home"]["rooms"][r]["therm_setpoint_temperature"]
                                roundSetpoint = round(setpoint, 1)
                                intSetpoint = int(math.floor(setpoint))
                                openWindow = dataT["home"]["rooms"][r]["open_window"]
                                if tType == "NRV":
                                    try:
                                        hpr = dataT["home"]["rooms"][r]["heating_power_request"]
                                        if hpr > 0:
                                            calling = "Yes"
                                        else:
                                            calling = "No"
                                    except:
                                        hpr = 0
                                        calling = "-"
                                stage = "mode"
                                mode = dataT["home"]["rooms"][r]["therm_setpoint_mode"]
                                boost = "Off"
                                if mode == "schedule":
                                    modeKey = indigo.kHvacMode.ProgramHeat
                                elif mode == "manual":
                                    modeKey = indigo.kHvacMode.Heat
                                    boost = "On"
                                elif mode == "max":
                                    modeKey = indigo.kHvacMode.Heat
                                    boost = "On"
                                elif mode == "hg":
                                    modeKey = indigo.kHvacMode.Cool
                                elif mode == "away":
                                    modeKey = indigo.kHvacMode.Cool
                                elif mode == "off":
                                    modeKey = indigo.kHvacMode.Off
                                else:
                                    modeKey = indigo.kHvacMode.Off
                                    indigo.server.log("Mode = "+mode, isError=True)
                                if boost == "On":
                                    endTime = int(dataT["home"]["rooms"][r]["therm_setpoint_end_time"])
                                    nowTime = int(time.time())
                                    minutesLeft = int((endTime - nowTime) / 60)
                                else:
                                    minutesLeft = 0
                                stage = "device update"
                                device = None
                                for dev in indigo.devices.iter("self"):
                                    if dev.address == modId:
                                        device = indigo.devices[dev.name]
                                if device != None:
                                    self.unreachableTCount[device.name] = 0
                                    if self.unreachableT.get(device.name, False) == True:
                                        indigo.server.log("Device %s is now reachable" % device.name)
                                        self.unreachableT[device.name] = False
                                    device.setErrorStateOnServer(None)
                                    keyValueList = [
                                        {'key':'temperatureInput1', 'value': roundTemp, 'uiValue': str(roundTemp)+"C"},
                                        {'key':'Temperature', 'value': roundTemp, 'uiValue': str(roundTemp)},
                                        {'key':'IntegerTemperature', 'value': intTemp, 'uiValue':str(intTemp)},
                                        {'key':'setpointHeat', 'value':roundSetpoint, 'uiValue': str(roundSetpoint)+"C"},
                                        {'key':'Setpoint', 'value':roundSetpoint, 'uiValue': str(roundSetpoint)},
                                        {'key':'IntegerSetpoint', 'value': intSetpoint, 'uiValue': str(intSetpoint)},
                                        {'key':'hvacOperationMode', 'value': modeKey},
                                        {'key':'BoilerStatus', 'value': boilerStatusString},
                                        {'key':'ScheduleInUse', 'value': self.scheduleInUse},
                                        {'key':'CurrentZone', 'value': self.zoneName},
                                        {'key':'Mode', 'value': mode.capitalize()},
                                        {'key':'PreHeat', 'value': preheat},
                                        {'key':'TRVCallingForHeat', 'value': calling},
                                        {'key':'Boost', 'value': boost},
                                        {'key':'BoostMinsRemaining', 'value': minutesLeft},
                                        {'key':'DefaultBoostPeriod', 'value': self.defaultBoostPeriod},
                                        {'key':'OpenWindow', 'value': openWindow},
                                        {'key':'DeviceType', 'value': deviceType},
                                        {'key':'Reachable', 'value': reachable},
                                        {'key':'Firmware', 'value': firmware},
                                        {'key':'batteryLevel', 'value':batteryPercent},
                                        {'key':'BatteryState', 'value': batteryState},
                                        {'key':'RadioStrength', 'value': radio},
                                    ]
                                    device.updateStatesOnServer(keyValueList)
                                    if tType == "NRV":
                                        device.updateStateOnServer(key="ValvePosition", value=hpr, uiValue=str(hpr)+"%")
                                    if self.showSetpointInNotes:
                                        device.description = "{:>6}".format(str(roundSetpoint)+"C")
                                        device.replaceOnServer()
                                    elif device.description != "":
                                        device.description = ""
                                        device.replaceOnServer()
                                    if tType == "NATherm1":
                                        if boilerStatus == "True":
                                            device.updateStateImageOnServer(indigo.kStateImageSel.HvacHeating)
                                        else:
                                            device.updateStateImageOnServer(indigo.kStateImageSel.HvacHeatMode)
                                    elif tType == "NRV":
                                        if hpr > 0:
                                            device.updateStateImageOnServer(indigo.kStateImageSel.HvacHeating)
                                        else:
                                            device.updateStateImageOnServer(indigo.kStateImageSel.HvacHeatMode)
            
                                if not self.thermOK:
                                    self.thermOK = True
                    
            except (requests.Timeout, requests.exceptions.HTTPError) as error:
                if self.thermOK:
                    e = self.getErrorText(error.response.text)
                    indigo.server.log("Thermostat update timeout: %s" % (e), isError=True)
                    self.thermOK = False
                    
            except:
              if self.thermOK:
                  e = sys.exc_info()[0]
                  f = sys.exc_info()[1]
                  indigo.server.log("Thermostat update error: %s, %s" % (e, f), isError=True)
                  indigo.server.log("Device reachable is %s" % reachable)
                  indigo.server.log("Stage %s" % stage)
                  self.thermOK = False
                  
        #indigo.server.log(json.dumps(self.unreachableT, indent=4, sort_keys=True))
        self.lastUpdateTimeTherm = time.time()


    def updateIndigoHouse(self, dataX):
        # Update room and schedule information
        if self.loggingTherm:
            indigo.server.log("Thermostat Homes Data:\n"+str(dataX))
        today = datetime.date.today()
        last_monday = today - datetime.timedelta(days=today.weekday())
        unixMon = time.mktime(time.strptime(str(last_monday), '%Y-%m-%d'))
        unixNow = time.time()
        timesince = unixNow - unixMon
        minutessince = int(timesince / 60)
        self.homeId = dataX["homes"][0]["id"]
        if self.useAppDefault == True:
            self.defaultBoostPeriod = int(dataX["homes"][0]["therm_setpoint_default_duration"])
        else:
            self.defaultBoostPeriod = int(self.defaultBoostHours) * 60
        max_rooms = len(dataX["homes"][0]["rooms"])
        for r in range (0, max_rooms):
            roomId = dataX["homes"][0]["rooms"][r]["id"]
            roomName = dataX["homes"][0]["rooms"][r]["name"]
            self.rooms[roomId] = roomName
        max_mods = len(dataX["homes"][0]["modules"])
        for m in range(0, max_mods):
            modType = dataX["homes"][0]["modules"][m]["type"]
            if (modType == "NATherm1") or (modType == "NRV"):
                modId = dataX["homes"][0]["modules"][m]["id"]
                modRoomId = dataX["homes"][0]["modules"][m]["room_id"]
                modRoomName = self.rooms[modRoomId]
                self.locations[modId] = modRoomId
        self.max_schedules = len(dataX["homes"][0]["schedules"])
        for sched in range(0, self.max_schedules):
            self.scheduleList.insert(sched, dataX["homes"][0]["schedules"][sched]["name"])
            self.scheduleIdList.insert(sched, dataX["homes"][0]["schedules"][sched]["id"])
            try:
                # 'selected' key is only present for selected schedule
                selected = dataX["homes"][0]["schedules"][sched]["selected"]
                self.scheduleInUse = dataX["homes"][0]["schedules"][sched]["name"]
                max_zones = len(dataX["homes"][0]["schedules"][sched]["zones"])
                for z in range (0, max_zones):
                    zone_id = dataX["homes"][0]["schedules"][sched]["zones"][z]["id"]
                    zone_name = dataX["homes"][0]["schedules"][sched]["zones"][z]["name"]
                    self.zones[zone_id] = zone_name
                max_offsets = len(dataX["homes"][0]["schedules"][sched]["timetable"])
                for v in range (0, max_offsets):
                    offset = dataX["homes"][0]["schedules"][sched]["timetable"][v]["m_offset"]
                    if int(offset) > minutessince:
                        zoneId = dataX["homes"][0]["schedules"][sched]["timetable"][v-1]["zone_id"]
                        self.zoneName = str(self.zones[zoneId])
                        break
            except:
                pass
        self.lastUpdateTimeHouse = time.time()
        

    def checkEvent(self, dataE, camE):
        # Checks the last 20 events for the last for each camera
        lastEvent = "None"
        lastEventTime = time.strftime('%d-%b-%y %H:%M')
        camEventFound = "No"
        eventPointer = -1
        for e in range (0, 20):
            cameraId = dataE["homes"][0]["events"][e]["camera_id"]
            if cameraId == camE:
                messageType = dataE["homes"][0]["events"][e]["type"]
                if messageType == 'outdoor':
                    lastEventRaw = dataE["homes"][0]["events"][e]["event_list"][0]["message"]
                    lastEventTimeRaw = dataE["homes"][0]["events"][e]["event_list"][0]["time"]
                else:
                    lastEventRaw = dataE["homes"][0]["events"][e]["message"]
                    lastEventTimeRaw = dataE["homes"][0]["events"][e]["time"]
                lastEvent = re.sub('<[^<]+?>', '', lastEventRaw)
                lastEventTime = time.strftime('%d-%b-%y %H:%M', time.localtime(lastEventTimeRaw))
                camEventFound = "Yes"
                eventPointer = e
                break
        return lastEvent, lastEventTime, camEventFound, eventPointer


    def limescaleProtectGo(self):
        # Drives TRVs closed/open for a period to protect against limescale build-up
        iterator = indigo.devices.iter(filter="self.netatmoTherm")
        for dev in iterator:
            if indigo.devices[dev.id].states["DeviceType"] == "TRV":
                indigo.server.log("%s limescale protection sequence initiated" % dev.name) 
                roomId = self.locations[dev.address]
                self.trvClose(roomId)
                now = int(time.time())
                openTime = now + (int(self.limeTime) * 60)
                self.openList[roomId] = openTime                
                self.sleep(5)
        self.lpRequest = False
        self.lpComplete = True


    def trvClose(self, roomId):
        # Used by limescale protect functions
        holdTemp = "8"
        now = int(time.time())
        endTime = str(now + (int(self.limeTime) * 60))
        payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': holdTemp, 'endtime': endTime}
        try:
            response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
            response.raise_for_status()
            return True
        except:
            indigo.server.log("Limescale protection close TRV error", isError=True)
            return False


    def trvOpen(self, roomId):
        # Used by limescale protect functions
        holdTemp = "30"
        now = int(time.time())
        endTime = str(now + (int(self.limeTime) * 60))
        payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': holdTemp, 'endtime': endTime}
        try:
            response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
            response.raise_for_status()
            return True
        except:
            indigo.server.log("Limescale protection open TRV error", isError=True)
            return False
        

    def listGeneratorA(self, filter="", valuesDict=None, typeId="", targetId=0):
        returnArray = []
        for sched in range(0, self.max_schedules):
            name = self.scheduleList[sched]
            returnArray.append(name)
        return sorted(returnArray,key=lambda x: x[1])
        
        
    def listGeneratorB(self, filter="", valuesDict=None, typeId="", targetId=0):
        returnArray = []
        iterator = indigo.devices.iter(filter="self.netatmoTherm")
        for dev in iterator:
            if indigo.devices[dev.id].states["DeviceType"] == "TRV":
                returnArray.append(dev.name)
        return sorted(returnArray,key=lambda x: x[1])


    def tempUnits(self, temp, corf):
        #Convert degC to degF if imperial units are selected
        if corf == 0:
            return round(temp, 1)
        else:
            return round(((temp * 1.8) + 32), 1)
        

    def degToCompass(self, num):
        #Convert degrees to compass directions
        val=int((num/22.5) + 0.5)
        arr=["N","NNE","NE","ENE","E","ESE", "SE", "SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"]
        return arr[(val % 16)]


    def kphToBft(self, kph):
        #Convert wind from kph to Beaufort scale
        if kph is None:
            return None
        for bft in range(len(self.bftThreshold)):
            if kph < self.bftThreshold[bft]:
                return bft
        return len(self.bftThreshold)


    def getErrorText(self, html):
        #Extract error text from html error message
        i = html.find("<title>")
        if i != -1:
            j = html.find("</title>")
            return html[i+7:j]
        else:
            return "Unknown error"
            
            
    def readingChanged(self, dev, timestampF):
        # Checks latest reading and last reading timestamps and returns True if reading has changed
        timestampUtc = time.strptime(timestampF, "%d-%b-%y %H:%M")
        try:
            lastReading = dev.states["LastReading"]
            lastReadingUtc = time.strptime(lastReading, "%d-%b-%y %H:%M")
        except:
            lastReadingUtc = 0
        return (timestampUtc != lastReadingUtc)

    
    def authenticate(self, userName, userPass, clientId, clientSecret):
        #Obtain correct authentication for selected device types
        if self.loggingCam or self.loggingMon or self.loggingWs or self.loggingSd:
            indigo.server.log("Authenticating...")
        scope = ""
        deviceTypeCount = 0
        logging = self.loggingCam or self.loggingWs or self.loggingMon or self.loggingTherm
        
        if self.presence:
            if logging:
                indigo.server.log("Authenticating for Presence Camera(s)")
            scope = scope + 'read_presence access_presence '
            deviceTypeCount += 1
         
        if self.welcome:
            if logging:
                indigo.server.log("Authenticating for Welcome Camera(s)")
            scope = scope + 'read_camera write_camera access_camera '
            deviceTypeCount += 1
               
        if self.weather:
            if logging:
                indigo.server.log("Authenticating for Weather Station(s)")
            scope = scope + 'read_station '
            deviceTypeCount += 1
                
        if self.healthyHome:
            if logging:
                indigo.server.log("Authenticating for Healthy Home Monitor(s)")
            scope = scope + 'read_homecoach '
            deviceTypeCount += 1
               
        if self.smoke:
            if logging:
                indigo.server.log("Authenticating for Smoke Detector(s)")
            scope = scope +  'read_smokedetector '
            deviceTypeCount += 1
               
        if self.therm:
            if logging:
                indigo.server.log("Authenticating for Thermostat(s)")
            scope = scope +  'read_thermostat write_thermostat '
            deviceTypeCount += 1

        scope = scope[:-1]  #Remove trailing space
                
        if deviceTypeCount == 0:
            indigo.server.log("Invalid authentication call", isError=True)
            return

        if logging:
            indigo.server.log("Requested: " + scope)       
        try:
            payload = {'grant_type': 'password',
                'client_id': clientId,
                'client_secret': clientSecret,
                'username': userName,
                'password': userPass,
                'scope': scope,
            }
            response = requests.post("https://api.netatmo.com/oauth2/token", data=payload, timeout=self.timeout)
            response.raise_for_status()
            self.accessToken=response.json()["access_token"]
            self.refreshToken=response.json()["refresh_token"]
            self.expiration = int(response.json()['expire_in'] + time.time())
            if self.saveTokens:
                self.pluginPrefs["accessToken"] = self.accessToken
                self.pluginPrefs["refreshToken"] = self.refreshToken
                self.pluginPrefs["expiration"] = self.expiration
            if self.loggingCam or self.loggingMon or self.loggingWs or self.loggingTherm:
                indigo.server.log("Your access token is: "+str(self.accessToken))
                indigo.server.log("Your refresh token is: "+str(self.refreshToken))
            return "OK", response.status_code 
        #except requests.exceptions.ConnectionError:
            #indigo.server.log("Authenticate error - cannot connect to Netatmo servers", isError=True)
        #   self.commsOK = False
        #   return "error"
        except (requests.Timeout, requests.exceptions.RequestException) as e:
            return "error", str(e)

         
    def refresh(self, clientId, clientSecret, refreshToken):
        #Refresh Netatmo token on expiry
        if self.loggingCam or self.loggingMon or self.loggingWs or self.loggingTherm:
            indigo.server.log("Refreshing Netatmo token...")
            
        payload = {'grant_type': 'refresh_token',
           'refresh_token': refreshToken,
           'client_id': clientId,
           'client_secret': clientSecret,}
        try:
            response = requests.post("https://api.netatmo.com/oauth2/token", data=payload, timeout=self.timeout)
            response.raise_for_status()
            self.accessToken=response.json()["access_token"]
            self.refreshToken=response.json()["refresh_token"]
            self.expiration = int(response.json()['expire_in'] + time.time())
            if self.saveTokens:
                self.pluginPrefs["accessToken"] = self.accessToken
                self.pluginPrefs["refreshToken"] = self.refreshToken
                self.pluginPrefs["expiration"] = self.expiration
            if self.loggingCam or self.loggingMon or self.loggingWs or self.loggingTherm:
                indigo.server.log("Your access token is: "+str(self.accessToken))
                indigo.server.log("Your refresh token is: "+str(self.refreshToken))
            return "OK", response.status_code
        #except requests.exceptions.ConnectionError:
            #indigo.server.log("Refresh error - cannot connect to Netatmo servers", isError=True)
        #   return "error"
        except (requests.Timeout, requests.exceptions.RequestException) as e:
            self.authenticate(self.userName, self.userPass, self.clientId, self.clientSecret)
            return "error", str(e)
            
            
    def delForgottenPersons(self):
    
        #Checks for person and Last Seen variables in Netatmo folder which are no longer
        # being reported by Netatmo, and deletes them if they have no dependencies.  If
        # dependencies exist an error message and details are published in the Event Log.
        personsDeleted = 0
        for var in indigo.variables.iter("self"):
            if (var.folderId == self.netatmoFolderId) and ("_last_seen" not in var.name) and (var.name[0] != "_"):
                if var.name not in self.currentPersonsList:
                    indigo.server.log(var.name+" not in current Netatmo persons list")
                    depsList = indigo.variable.getDependencies(var)
                    #indigo.server.log(str(depsList))
                    if any (depsList.itervalues()):
                        lenAct = len(depsList["actionGroups"])
                        lenCon = len(depsList["controlPages"])
                        lenDev = len(depsList["devices"])
                        lenSch = len(depsList["schedules"])
                        lenTri = len(depsList["triggers"])
                        lenVar = len(depsList["variables"])
                        indigo.server.log("Variable "+var.name+" has dependencies - cannot delete", isError=True)
                        indigo.server.log("%d action group dependencies" % lenAct)
                        indigo.server.log("%d control page dependencies" % lenCon)
                        indigo.server.log("%d device dependencies" % lenDev)
                        indigo.server.log("%d schedule dependencies" % lenSch)
                        indigo.server.log("%d trigger dependencies" % lenTri)
                        indigo.server.log("%d variable dependencies" % lenVar)
                    else:
                        indigo.variable.delete(var)
                        indigo.server.log("Variable "+var.name+" deleted")
                        personsDeleted = personsDeleted + 1    
                        vLastSeen = var.name+"_last_seen"
                        if  (vLastSeen in indigo.variables):
                            indigo.variable.delete(vLastSeen)
                            indigo.server.log("Variable "+vLastSeen+" deleted")
        return personsDeleted
        

        
    ########################################
    # Menu Item functions
    ######################
    
    def updateReadingsNow(self):
    
        #Ad hoc poll for latest data
        self.lastUpdateTimeHH = 0
        self.lastUpdateTimeWS = 0
        self.lastUpdateTimeWSTP = 0
        self.getUpdate() 
        indigo.server.log("Manual update of readings is complete")
    
    
    def removeDeletedPersons(self):
    
        #Deletes person and last seen variables for people not in current Netatmo reply
        if self.welcome:   
            indigo.server.log("Checking for deleted persons...")
            numberDeleted = self.delForgottenPersons()
            if numberDeleted == 0:
                indigo.server.log("All persons are in the current list; no variables deleted")
        else:
            indigo.server.log("Invalid request - no Welcome camera present")


    def limescaleProtectNow(self):
        indigo.server.log("Initiating TRV Limescale Protection")
        self.lpRequest = True


    def requestAccessToken(self):

        #Destroys Access Token, forcing a request for a replacement
        self.accessToken = ""
        indigo.server.log("New Access Token requested")
    


    #######################################
    # Action functions
    ######################
    
    def setPersonAway(self, action):
    
        if self.welcome:
            name = action.props.get("name", "")
            if name in self.personId:
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'person_id': self.personId[name], 'size': 2,}
                try:
                    response = requests.post("https://api.netatmo.com/api/setpersonsaway", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(name+" set away")
                except:
                    indigo.server.log("Set Person Away - server access error", isError=True)
            else:
                indigo.server.log("Set Person Away - "+name+" not found", isError=True)
        else:
            indigo.server.log("Invalid request - no Welcome camera present")

            
    def setAllAway(self, action):
    
        if self.welcome:
            payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'size': 2,}
            try:
                response = requests.post("https://api.netatmo.com/api/setpersonsaway", data=payload, timeout=self.timeout)
                response.raise_for_status()
                indigo.server.log("All persons set away")
            except:
                indigo.server.log("Set All Away - server access error", isError=True)
        else:
            indigo.server.log("Invalid request - no Welcome camera present")


    def setPersonHome(self, action):
    
        if self.welcome:
            name = action.props.get("name", "")
            if name in self.personId:
#                 pArray = "{"+self.personId[name]+"}"
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'person_ids[]': self.personId[name],}
                try:
                    response = requests.post("https://api.netatmo.com/api/setpersonshome", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(name+" set home")
                except:
                    indigo.server.log("Set Person Home - server access error", isError=True)
            else:
                indigo.server.log("Set Person Home - "+name+" not found", isError=True)
        else:
            indigo.server.log("Invalid request - no Welcome camera present")


    def takeSnapshot(self, action):

        errorDict = indigo.Dict()
#         try:
        devId = action.props.get("devId", "")
        if devId == "":
            indigo.server.log("Please specify a camera device for snapshot", isError=True)
            return False
        if self.snapshotPath == "":
            indigo.server.log("Please specify a folder path for snapshot", isError=True)
            return False
        device = indigo.devices[int(devId)]
        cam = device.address
        camName = device.name
        if self.camUrl[cam] != "":
            imgLoc = self.snapshotPath+"/%s %s.jpg" % (camName, datetime.datetime.now().strftime('%Y-%m-%d %H-%M-%S'))
            request = urllib.request.Request(self.camUrl[cam]+"/live/snapshot_720.jpg") 
            buffer = urllib.request.urlopen(request).read()
            f = open(imgLoc, 'wb')
            f.write(buffer)
            f.close()
            return True
        else:
            indigo.server.log("Missing URL for camera snapshot", isError=True)
#         except:
#             indigo.server.log("Snapshot error", isError=True)
#             return False

            
    def setMode(self, pluginAction):
    
        devToProcess = pluginAction.deviceId
        device = None
        for dev in indigo.devices.iter("self"):
            if dev.id == devToProcess:
                device = indigo.devices[dev.name]
        if device != None:
            mode = pluginAction.props["mode"]
            if mode == "schedule":
                modeKey = indigo.kHvacMode.ProgramHeat
            elif mode == "manual":
                modeKey = indigo.kHvacMode.Heat
            elif mode == "hg":
                modeKey = indigo.kHvacMode.Cool
            elif mode == "away":
                modeKey = indigo.kHvacMode.Off
            else:
                modeKey = 0 
            keyValueList = [
                {'key':'hvacOperationMode', 'value': modeKey},
                {'key':'Mode', 'value': mode},
            ]
            device.updateStatesOnServer(keyValueList)
            if mode == "manual":
                setpoint = indigo.devices[device.id].states["setpointHeat"]
                roomId = self.locations[device.address]
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': setpoint}
                try:
                    response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(device.name+" operating mode changed to '"+mode+"'")
                    self.getThermUpdate()
                except:
                    indigo.server.log("Thermostat mode change error", isError=True)                

            else:
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'mode': mode}
                try:
                    response = requests.post("https://api.netatmo.com/api/setthermmode", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(device.name+" operating mode changed to '"+mode+"'")
                    self.getThermUpdate()
                except:
                    indigo.server.log("Thermostat mode change error - cannot change to '"+mode+"'", isError=True)


    def setOverride(self, pluginAction):
    
        devToProcess = pluginAction.deviceId
        device = None
        for dev in indigo.devices.iter("self"):
            if dev.id == devToProcess:
                device = indigo.devices[dev.name]
        if device != None:
            roomId = self.locations[device.address]
            holdTemp = str(pluginAction.props["overrideTemp"])
            holdHours = pluginAction.props["numberOfHours"]
            holdSecs = float(holdHours) * 3600
            now = int(time.time())
            endTime = str(now + holdSecs)
            payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': holdTemp, 'endtime': endTime}
            try:
                response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                response.raise_for_status()
                indigo.server.log(device.name+" override to %s degC for %s hour(s)" % (holdTemp, holdHours.lstrip("0")))
                self.getThermUpdate()
            except:
                indigo.server.log("Thermostat override error", isError=True)
                

    def cancelOverride(self, pluginAction):
    
        devToProcess = pluginAction.deviceId
        device = None
        for dev in indigo.devices.iter("self"):
            if dev.id == devToProcess:
                device = indigo.devices[dev.name]
        if device != None:
            mode = "schedule"
            modeKey = indigo.kHvacMode.ProgramHeat
            keyValueList = [
                {'key':'hvacOperationMode', 'value': modeKey},
                {'key':'Mode', 'value': mode},
            ]
            device.updateStatesOnServer(keyValueList)
            payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'mode': mode}
            try:
                response = requests.post("https://api.netatmo.com/api/setthermmode", data=payload, timeout=self.timeout)
                response.raise_for_status()
                indigo.server.log(device.name+" override cancelled")
                self.getThermUpdate()
            except:
                indigo.server.log("Thermostat override cancel error", isError=True)
                

    def toggleOverride(self, pluginAction):
    
        devToProcess = pluginAction.deviceId
        device = None
        for dev in indigo.devices.iter("self"):
            if dev.id == devToProcess:
                device = indigo.devices[dev.name]
        if device != None:
            currentMode = indigo.devices[device.id].states["Mode"]
            indigo.server.log(currentMode)
            if currentMode == "manual":
                mode = "schedule"
                modeKey = indigo.kHvacMode.ProgramHeat
                keyValueList = [
                    {'key':'hvacOperationMode', 'value': modeKey},
                    {'key':'Mode', 'value': mode},
                ]
                device.updateStatesOnServer(keyValueList)
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'mode': mode}
                try:
                    response = requests.post("https://api.netatmo.com/api/setthermmode", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(device.name+" override cancelled")
                    self.getThermUpdate()
                except:
                    indigo.server.log("Thermostat override cancel error", isError=True)
            elif currentMode == "schedule":
                roomId = self.locations[device.address]
                holdTemp = self.defaultBoostTemp
                if self.useAppDefault == True:
                    holdMins = self.defaultBoostPeriod
                    holdSecs = int(holdMins) * 60
                else:
                    holdHours = self.defaultBoostHours
                    holdSecs = int(holdHours) * 3600
                now = int(time.time())
                endTime = str(now + holdSecs)
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': holdTemp, 'endtime': endTime}
                try:
                    response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(device.name+" override to %s degC for %s hour(s)" % (holdTemp, holdHours.lstrip("0")))
                    self.getThermUpdate()
                except:
                    indigo.server.log("Thermostat override error", isError=True)                    
            else:
                indigo.server.log("Invalid override request", isError=True)


    def changeSchedule(self, pluginAction):
        errorDict = indigo.Dict()
        newSchedule = pluginAction.props.get("newSchedule", "")
        ind = self.scheduleList.index(newSchedule)
        newScheduleId = self.scheduleIdList[ind]
        if newSchedule == "":
            errorDict["newSchedule"] = "Please select a schedule from the list"
            errorDict["showAlertText"] = "Please select a schedule from the list"
            return (False, pluginAction, errorDict)
        payload = {
            'access_token': self.accessToken,
            'home_id': self.homeId,
            'schedule_id': newScheduleId
        }
        try:
            response = requests.post("https://api.netatmo.com/api/switchhomeschedule", data=payload, timeout=self.timeout)
            response.raise_for_status()
            indigo.server.log("Heating schedule changed to '"+newSchedule+"'")
            self.sleep(2)
            self.getHouseUpdate()
            self.sleep(1)
            self.getThermUpdate()
        except:
            indigo.server.log("Error when changing to "+"'"+newSchedule+"'", isError=True)
            errorDict["newSchedule"] = "Schedule change error"
            errorDict["showAlertText"] = "Schedule change error"
            return (False, pluginAction, errorDict)
        return True


    def lsProtect(self, pluginAction):
        # Drives TRVs open/closed for 5 minutes to protect against limescale build-up
        devToProcess = pluginAction.props.get("devId", "")
        indigo.server.log("%s limescale protection sequence initiated" % devToProcess)
        device = None
        for dev in indigo.devices.iter("self"):
            if dev.name == devToProcess:
                device = indigo.devices[dev.name]
        if device != None:
            roomId = self.locations[device.address]
            self.trvClose(roomId)
            # Add TRV to list of valves to be opened after time delay
            openTime = now + 360
            self.openList[roomId] = openTime  
            return True
        else:
            indigo.server.log("Limescale protection: device not found", isError=True)


                
    ########################################
    # Netatmo Thermostat/TRV Action callback
    ######################
    # Main thermostat action bottleneck called by Indigo Server.

    def actionControlThermostat(self, action, dev):
        if action.thermostatAction == indigo.kThermostatAction.SetHeatSetpoint:
            newSetpoint =  round(action.actionValue * 2) / 2
            if newSetpoint != action.actionValue:
                warning = " (Setpoint rounded to nearest half degree)"
            else:
                warning = ""
            roomId = self.locations[dev.address]
            payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': newSetpoint}
            try:
                response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                response.raise_for_status()
                intSetpoint = int(math.floor(newSetpoint))
                keyValueList = [
                {'key':'setpointHeat', 'value': newSetpoint, 'uiValue': str(newSetpoint)+"C"},
                {'key':'Setpoint', 'value': newSetpoint, 'uiValue': str(newSetpoint)},
                {'key':'IntegerSetpoint', 'value': intSetpoint, 'uiValue': str(intSetpoint)},
                ]
                dev.updateStatesOnServer(keyValueList)
                indigo.server.log(dev.name+" setpoint changed to "+str(newSetpoint)+" degC"+warning)
                if self.showSetpointInNotes:
                    dev.description = "{:>6}".format(str(newSetpoint)+"C")
                    dev.replaceOnServer()
                elif dev.description != "":
                    dev.description = ""
                    dev.replaceOnServer()
            except:
                indigo.server.log("Thermostat set setpoint error", isError=True)
            
        elif action.thermostatAction == indigo.kThermostatAction.DecreaseHeatSetpoint:
            newSetpoint = dev.heatSetpoint - action.actionValue
            if newSetpoint != dev.heatSetpoint:
                intSetpoint = int(math.floor(newSetpoint))
                keyValueList = [
                {'key':'setpointHeat', 'value': newSetpoint, 'uiValue': str(newSetpoint)+"C"},
                {'key':'Setpoint', 'value': newSetpoint, 'uiValue': str(newSetpoint)},
                {'key':'IntegerSetpoint', 'value': intSetpoint, 'uiValue': str(intSetpoint)},
                ]
                dev.updateStatesOnServer(keyValueList)
                roomId = self.locations[dev.address]
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': newSetpoint}
                try:
                    response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(dev.name+" setpoint decreased to "+str(newSetpoint)+" degC")
                    if self.showSetpointInNotes:
                        dev.description = "{:>6}".format(str(newSetpoint)+"C")
                        dev.replaceOnServer()
                    elif dev.description != "":
                        dev.description = ""
                        dev.replaceOnServer()
                except:
                    indigo.server.log("Thermostat decrease setpoint error", isError=True)
        
        elif action.thermostatAction == indigo.kThermostatAction.IncreaseHeatSetpoint:
            newSetpoint = dev.heatSetpoint + action.actionValue
            if newSetpoint != dev.heatSetpoint:
                intSetpoint = int(math.floor(newSetpoint))
                keyValueList = [
                {'key':'setpointHeat', 'value': newSetpoint, 'uiValue': str(newSetpoint)+"C"},
                {'key':'Setpoint', 'value': newSetpoint, 'uiValue': str(newSetpoint)},
                {'key':'IntegerSetpoint', 'value': intSetpoint, 'uiValue': str(intSetpoint)},
                ]
                dev.updateStatesOnServer(keyValueList)
                roomId = self.locations[dev.address]
                payload = {'access_token': self.accessToken, 'home_id': self.homeId, 'room_id': roomId, 'mode': 'manual', 'temp': newSetpoint}
                try:
                    response = requests.post("https://api.netatmo.com/api/setroomthermpoint", data=payload, timeout=self.timeout)
                    response.raise_for_status()
                    indigo.server.log(dev.name+" setpoint increased to "+str(newSetpoint)+" degC")
                    if self.showSetpointInNotes:
                        dev.description = "{:>6}".format(str(newSetpoint)+"C")
                        dev.replaceOnServer()
                    elif dev.description != "":
                        dev.description = ""
                        dev.replaceOnServer()
                except:
                    indigo.server.log("Thermostat increase setpoint error", isError=True)

